<?php
    include("connection.php");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Employee Registration</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: linear-gradient(135deg, #ff9a9e, #fad0c4, #fad0c4, #ffdde1, #c6ffdd, #fbc2eb, #a1c4fd);
            background-size: 200% 200%;
            animation: gradientBG 10s ease infinite;
            display: flex;
            justify-content: center;
            align-items: center;
            margin: 50px;
        }

        @keyframes gradientBG {
            0% { background-position: 0% 50%; }
            50% { background-position: 100% 50%; }
            100% { background-position: 0% 50%; }
        }

        .registration-form {
            background: rgba(255, 255, 255, 0.9);
            padding: 25px;
            width: 500px;
            border-radius: 12px;
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.15);
            animation: fadeIn 1.5s;
        }

        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .registration-form h2 {
            text-align: center;
            color: #333;
            font-size: 1.8em;
            margin-bottom: 20px;
            text-shadow: 1px 1px 2px #fff;
        }

        .registration-form label {
            font-weight: bold;
            color: #444;
        }

        .registration-form input,
        .registration-form select {
            width: 100%;
            padding: 10px;
            margin: 8px 0 15px 0;
            border: 1px solid #ddd;
            border-radius: 6px;
            box-sizing: border-box;
            transition: all 0.3s ease;
        }

        .registration-form input:focus,
        .registration-form select:focus {
            border-color: #8e44ad;
            box-shadow: 0px 0px 5px rgba(142, 68, 173, 0.3);
        }

        .registration-form button {
            width: 100%;
            padding: 12px;
            background: linear-gradient(135deg,green,yellow);
            color: #fff;
            font-weight: bold;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            transition: all 0.3s ease;
            box-shadow: 0px 4px 15px rgba(255, 150, 150, 0.2);
        }

        .registration-form button:hover {
            background: linear-gradient(135deg, #fad0c4, #ff9a9e);
            box-shadow: 0px 4px 20px rgba(255, 150, 150, 0.4);
            transform: translateY(-2px);
        }


        .registration-form label, .registration-form h2, .registration-form button {
            text-shadow: 1px 1px 2px rgba(255, 255, 255, 0.6);
        }
        </style>
</head>
<body>

<div class="registration-form">
    <h2>Employee Registration</h2>
    <form method="post" action="">
        <label for="emp_name">Employee Name:</label>
        <input type="text" name="emp_name" required>

        <label for="emp_no">Employee Number:</label>
        <input type="text" name="emp_no" required>

        <label for="dept">Department:</label>
        <select name="dept" required>
            <option value="">Select Department</option>
            <option value="AIDS">AIDS</option>
            <option value="AIML">AIML</option>
            <option value="CSE">CSE</option>
            <option value="CIVIL">CIVIL</option>
            <option value="MECH">MECH</option>
            <option value="EEE">EEE</option>
            <option value="ECE">ECE</option>
            <option value="IT">IT</option>
            <option value="BSH">BSH</option>
        </select>

        <label for="date_of_joining">Date of Joining:</label>
        <input type="date" name="date_of_joining" required>

        <label for="aadhar">Aadhar Card Number:</label>
        <input type="text" name="aadhar" pattern="\d{12}" required title="Aadhar should be 12 digits">

        <label for="pan">PAN Card Number:</label>
        <input type="text" name="pan" pattern="[A-Z]{5}[0-9]{4}[A-Z]" required title="PAN should be 10 characters">

        <label for="phone">Phone Number:</label>
        <input type="text" name="phone" pattern="\d{10}" required title="Phone number should be 10 digits">

        <label for="address">Address:</label>
        <input type="text" name="address" required>

        <label for="orc_id">ORC ID:</label>
        <input type="text" name="orc_id" required>

        <label for="scopus_id">SCOPUS ID:</label>
        <input type="text" name="scopus_id">

        <label for="vidwan_id">VIDWAN ID:</label>
        <input type="text" name="vidwan_id">

        <label for="def_id">DEF ID:</label>
        <input type="text" name="def_id">

        <label for="username">Username:</label>
        <input type="text" name="username" required>

        <label for="password">Password:</label>
        <input type="password" name="password" required>

        <label for="conf_password">Confirm Password:</label>
        <input type="password" name="conf_password" required>

        <button type="submit" name="register">Register</button>
    </form>
</div>

<?php
if (isset($_POST['register'])) {
    $emp_name = $_POST['emp_name'];
    $emp_no = $_POST['emp_no'];
    $dept = $_POST['dept'];
    $date_of_joining = $_POST['date_of_joining'];
    $aadhar = $_POST['aadhar'];
    $pan = $_POST['pan'];
    $phone = $_POST['phone'];
    $address = $_POST['address'];
    $orc_id = $_POST['orc_id'];
    $scopus_id = $_POST['scopus_id'];
    $vidwan_id = $_POST['vidwan_id'];
    $def_id = $_POST['def_id'];
    $username = $_POST['username'];
    $password = $_POST['password'];
    $conf_password = $_POST['conf_password'];

    // Check if password and confirm password are equal
    if ($password != $conf_password) {
        ?><script>alert("The condition is not met. Please take action.");</script><?php
        exit();
    }

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Prepare statement to prevent SQL injection
    $stmt = $conn->prepare("INSERT INTO reg_tab (emp_name, emp_no, dept, date_of_joining, aadhar, pan, phone, address, orc_id, scopus_id, vidwan_id, def_id, username, password) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("ssssssssssssss", $emp_name, $emp_no, $dept, $date_of_joining, $aadhar, $pan, $phone, $address, $orc_id, $scopus_id, $vidwan_id, $def_id, $username, password_hash($password, PASSWORD_DEFAULT));
    
    if ($stmt->execute()) {
        echo "<p>Registration successful!</p>";
    } else {
        echo "<p class='error'>Error: " . $stmt->error . "</p>";
    }

    $stmt->close();
    $conn->close();
}
?>

</body>
</html>
