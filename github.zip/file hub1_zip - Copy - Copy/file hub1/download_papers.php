<?php
include("connection.php");
session_start();

if (!isset($_SESSION['username'])) {
    die("You need to log in to view your uploads.");
}

$username = $_SESSION['username'];
ob_start();// Start the buffer here

// Handle file deletion
if (isset($_GET['delete_id']) && isset($_GET['table'])) {
    $delete_id = intval($_GET['delete_id']);
    $table = $_GET['table']; // The table name passed in the URL
    $file_column = isset($_GET['file_column']) ? $_GET['file_column'] : ''; // The file column, if applicable

    // SQL query to fetch the file path from the database
    if ($file_column) {
        $sql = "SELECT $file_column FROM $table WHERE id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $delete_id);
        $stmt->execute();
        $result = $stmt->get_result();
        $file = $result->fetch_assoc();

        if ($file && !empty($file[$file_column])) {
            // Attempt to delete the file from the server
            if (file_exists($file[$file_column]))
            {
              if (unlink($file[$file_column])) {
                  // If file deletion is successful, delete the record from the database
                  $delete_sql = "DELETE FROM $table WHERE id = ?";
                  $delete_stmt = $conn->prepare($delete_sql);
                  $delete_stmt->bind_param("i", $delete_id);
                  $delete_stmt->execute();
                  $delete_stmt->close();
              }
            }
            else{
                // If file does not exist, just delete the record
                    $delete_sql = "DELETE FROM $table WHERE id = ?";
                    $delete_stmt = $conn->prepare($delete_sql);
                    $delete_stmt->bind_param("i", $delete_id);
                    $delete_stmt->execute();
                    $delete_stmt->close();
            }
        } else {
            // If the file does not exist, just delete the record
            $delete_sql = "DELETE FROM $table WHERE id = ?";
            $delete_stmt = $conn->prepare($delete_sql);
            $delete_stmt->bind_param("i", $delete_id);
            $delete_stmt->execute();
            $delete_stmt->close();
        }
    } else {
        // If no file column is provided, just delete the record
        $delete_sql = "DELETE FROM $table WHERE id = ?";
        $delete_stmt = $conn->prepare($delete_sql);
        $delete_stmt->bind_param("i", $delete_id);
        $delete_stmt->execute();
        $delete_stmt->close();
    }
   header("Location: ".$_SERVER['PHP_SELF']);
    exit();
}

///------------------------------------------------------------------------------------------------------------
// SQL query to fetch all records from the fdps_tab table

if (isset($_POST['export_fdps'])) {
    ob_end_clean();//End previous buffer
   ob_start();// start new buffer for excel
    header("Content-Type: application/vnd.ms-excel");
    header("Content-Disposition: attachment; filename=fdps_records.xls");

    // Write the Excel content header
    echo "Username\tBranch\tTitle\tDate From\tDate To\tOrganised By\tLocation\tSubmission Time\n";

    // Prepare and execute the SQL query
    $sql = "SELECT * FROM fdps_tab WHERE username = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();
    
    // Fetch and write data rows
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            echo $row['username'] . "\t" . 
                $row['branch'] . "\t" . 
                $row['title'] . "\t" . 
                $row['date_from'] . "\t" . 
                $row['date_to'] . "\t" . 
                $row['organised_by'] . "\t" . 
                $row['location'] . "\t" . 
                $row['submission_time'] . "\n";
        }
    }

    // End script execution
    ob_end_flush();//End current buffer
    exit;
}

// SQL query to fetch all records from the fdps_tab table
$sql_fdps = "SELECT * FROM fdps_tab WHERE username = ?";
$stmt_fdps = $conn->prepare($sql_fdps);
$stmt_fdps->bind_param("s", $username);
$stmt_fdps->execute();
$result_fdps = $stmt_fdps->get_result();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Uploads</title>
    <style>
        body {
            background: linear-gradient(135deg, #1e3c72, #2a5298);
            margin:0;
            margin-left:0px;
        }
        
        .div{
            margin-top: 0px;
        }
        .container11 {
            margin-top:20px;
            margin-left:50px;
            width: 90%;     
            padding: 20px;
            background: #fff;
            border-radius: 8px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
        }
        .container111 {
            margin-top:20px;
            margin-left:50px;
            padding-right:20px;
            width: 90%; /* Example width exceeding 100% */
            overflow-x: auto; /* Adds a horizontal scrollbar when content overflows */
            overflow-y: hidden; /* Optional: Hides vertical overflow if not needed */
            white-space: nowrap; 
            padding: 20px;
            background: #fff;
            border-radius: 8px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
        }
        
        h1 {
            text-align: center;
            color: rgb(63, 206, 239);
            text-decoration: underline;
            margin-top: 0px;
            padding-top:100px;
        }
        h2 {
            color:rgb(148, 124, 6);
            margin-bottom: 10px;
            text-transform: uppercase;
        }
        table {
            width: 100%;
            border-collapse: collapse;
        }
        th, td {
            text-align: left;
            padding: 12px;
            border: 1px solid #ddd;
        }
        h2{
            margin-left:50px;
        }
        th {
            background-color: #007bff;
            color: white;
        }
        tr:nth-child(even) {
            background-color: #f2f2f2;
        }
        tr:hover {
            background-color: #e9ecef;
        }
        button, #del {
            border: none;
            border-radius: 5px;
            padding: 8px 16px;
            font-size: 14px;
            cursor: pointer;
            text-transform: uppercase;
            font-weight: bold;
        }
        button#view {
            background-color: #28a745;
            color: white;
        }
        button#down {
            background-color: #007bff;
            color: white;
        }
        #del {
            background-color: #dc3545;
            color: white;
        }
        .no-files {
            text-align: center;
            color: #666;
            padding: 10px;
            font-style: italic;
        }
        .success-message, .error-message {
            text-align: center;
            color: #28a745;
            padding: 10px;
            font-weight: bold;
        }
        .error-message {
            color: #dc3545;
        }
        .ex_bt{
            margin-left:50px;
            background-color:rgb(125, 248, 238);
        }
    </style>
</head>
<body>
 <?php  include "header.php"; ?>
   
    <!-- Display the table and export button -->
<div class="div">
    <h1>My Uploads</h1>
    <h2>FDPS files</h2>
    <!-- Export to Excel Button -->
    <form method="POST">
        <button type="submit" class="ex_bt" name="export_fdps">Export to Excel</button>
    </form>
    <?php
    // Check if there are results
    if ($result_fdps->num_rows > 0) {
        // Start the table and add headers
        echo "<div class='container11'>
                <table border='1'>
                    <tr>
                        <th>Username</th>
                        <th>Branch</th>
                        <th>Title</th>
                        <th>Date From</th>
                        <th>Date To</th>
                        <th>Organised By</th>
                        <th>Location</th>
                        <th>Certificate</th>
                        <th>Submission Time</th>
                        <th>Action</th>
                    </tr>";

        // Output data of each row
        while ($row = $result_fdps->fetch_assoc()) {
            $certificatePath = htmlspecialchars($row["certificate"]);
             $deleteButton = "<form method='GET' action='' onsubmit='return confirm(\"Are you sure you want to delete this record?\")'>
                                <input type='hidden' name='delete_id' value='" . $row["id"] . "'>
                                <input type='hidden' name='table' value='fdps_tab'>
                                <input type='hidden' name='file_column' value='certificate'>
                                <input type='submit' id='del' value='Delete'>
                              </form>";

            echo "<tr>
                    <td>" . $row["username"] . "</td>
                    <td>" . $row["branch"] . "</td>
                    <td>" . $row["title"] . "</td>
                    <td>" . $row["date_from"] . "</td>
                    <td>" . $row["date_to"] . "</td>
                    <td>" . $row["organised_by"] . "</td>
                    <td>" . $row["location"] . "</td>
                    <td>
                        <a href='view_file1.php?file_path=" . urlencode($certificatePath) . "'><button id='view'>View</button></a>
                        <a href='" . htmlspecialchars($certificatePath) . "' download><button id='down'>Download</button></a>
                    </td>
                    <td>" . $row["submission_time"] . "</td>
                    <td>$deleteButton</td>
                </tr>";
        }
        // End the table
        echo "</table>
            </div>";
    } else {
        echo "<p class='no-files'>No uploads found.</p>";
    }

if (isset($_POST['export_fdps_org'])) {
     ob_end_clean();//End previous buffer
    ob_start();// start new buffer for excel
    header("Content-Type: application/vnd.ms-excel");
    header("Content-Disposition: attachment; filename=fdps_org.xls");

    // Write the Excel content header with the new columns
    echo "Username\tBranch\tTitle\tDate From\tDate To\tOrganised By\tLocation\tSubmission Time\n";

    // Prepare and execute the SQL query
    $sql = "SELECT * FROM fdps_org_tab WHERE username = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();
    
    // Fetch and write data rows
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            

            // Output data of each row
            echo $row['username'] . "\t" . 
                $row['branch'] . "\t" . 
                $row['title'] . "\t" . 
                $row['date_from'] . "\t" . 
                $row['date_to'] . "\t" . 
                $row['organised_by'] . "\t" . 
                $row['location'] . "\t" . 
                $row['submission_time'] . "\n";
        }
    }

    // End script execution
      ob_end_flush();//End current buffer
    exit;
}

///------------------------------------------------------------------------------------------------------------

// SQL query to fetch all records from the fdps_org_tab table
$sql_fdps_org = "SELECT * FROM fdps_org_tab WHERE username = ?";
$stmt_fdps_org = $conn->prepare($sql_fdps_org);
$stmt_fdps_org->bind_param("s", $username);
$stmt_fdps_org->execute();
$result_fdps_org = $stmt_fdps_org->get_result();

// Check if there are results
echo "<h2>FDPs Organised</h2>";?>
<form method="POST">
    <button type="submit" class="ex_bt" name="export_fdps_org">Export to Excel</button>
</form>
<?php
if ($result_fdps_org->num_rows > 0) {
    // Start the table and add headers
    echo "<div class='container111'>
            <table border='1'>
                <tr>
                    <th>Username</th>
                    <th>Branch</th>
                    <th>Title</th>
                    <th>Date From</th>
                    <th>Date To</th>
                    <th>Organised By</th>
                    <th>Location</th>
                    <th>Submission Time</th>
                    <th>Certificate</th>
                    <th>Brochure</th>
                    <th>Schedule/Invitation</th>
                    <th>Attendance Forms</th>
                    <th>Feedback Forms</th>
                    <th>Report</th>
                    <th>Photo 1</th>
                    <th>Photo 2</th>
                    <th>Photo 3</th>
                    <th>Action</th>
                </tr>";

    // Output data of each row
    while ($row = $result_fdps_org->fetch_assoc()) {
        $certificatePath = htmlspecialchars($row["certificate"]);
        $brochurePath = htmlspecialchars($row["brochure"]);
        $schedulePath = htmlspecialchars($row["fdp_schedule_invitation"]);
        $attendancePath = htmlspecialchars($row["attendance_forms"]);
        $feedbackPath = htmlspecialchars($row["feedback_forms"]);
        $reportPath = htmlspecialchars($row["fdp_report"]);
        $photo1Path = htmlspecialchars($row["photo1"]);
        $photo2Path = htmlspecialchars($row["photo2"]);
        $photo3Path = htmlspecialchars($row["photo3"]);

           $deleteButton = "<form method='GET' action='' onsubmit='return confirm(\"Are you sure you want to delete this record?\")'>
                            <input type='hidden' name='delete_id' value='" . $row["id"] . "'>
                            <input type='hidden' name='table' value='fdps_org_tab'>
                                 <input type='hidden' name='file_column' value='certificate'>
                            <input type='submit' id='del' value='Delete'>
                          </form>";

        echo "<tr>
                <td>" . $row["username"] . "</td>
                <td>" . $row["branch"] . "</td>
                <td>" . $row["title"] . "</td>
                <td>" . $row["date_from"] . "</td>
                <td>" . $row["date_to"] . "</td>
                <td>" . $row["organised_by"] . "</td>
                <td>" . $row["location"] . "</td>
                <td>" . $row["submission_time"] . "</td>
                <td>
                    <a href='view_file1.php?file_path=" . urlencode($certificatePath) . "'><button id='view'>View</button></a><br><br>
                    <a href='" . $certificatePath . "' download><button id='down'>Download</button></a>
                </td>
                <td>
                    <a href='view_file1.php?file_path=" . urlencode($brochurePath) . "'><button id='view'>View</button></a><br><br>
                    <a href='" . $brochurePath . "' download><button id='down'>Download</button></a>
                </td>
                <td>
                    <a href='view_file1.php?file_path=" . urlencode($schedulePath) . "'><button id='view'>View</button></a><br><br>
                    <a href='" . $schedulePath . "' download><button id='down'>Download</button></a>
                </td>
                <td>
                    <a href='view_file1.php?file_path=" . urlencode($attendancePath) . "'><button id='view'>View</button></a><br><br>
                    <a href='" . $attendancePath . "' download><button id='down'>Download</button></a>
                </td>
                <td>
                    <a href='view_file1.php?file_path=" . urlencode($feedbackPath) . "'><button id='view'>View</button></a><br><br>
                    <a href='" . $feedbackPath . "' download><button id='down'>Download</button></a>
                </td>
                <td>
                    <a href='view_file1.php?file_path=" . urlencode($reportPath) . "'><button id='view'>View</button></a><br><br>
                    <a href='" . $reportPath . "' download><button id='down'>Download</button></a>
                </td>
                <td>
                    <a href='view_file1.php?file_path=" . urlencode($photo1Path) . "'><button id='view'>View</button></a><br><br>
                    <a href='" . $photo1Path . "' download><button id='down'>Download</button></a>
                </td>
                <td>
                    <a href='view_file1.php?file_path=" . urlencode($photo2Path) . "'><button id='view'>View</button></a><br><br>
                    <a href='" . $photo2Path . "' download><button id='down'>Download</button></a>
                </td>
                <td>
                    <a href='view_file1.php?file_path=" . urlencode($photo3Path) . "'><button id='view'>View</button></a><br><br>
                    <a href='" . $photo3Path . "' download><button id='down'>Download</button></a>
                </td>
                <td>$deleteButton</td>
            </tr>";
    }
    // End the table
    echo "</table>
        </div>";
} else {
    echo "<p class='no-files'>No FDP records found.</p>";
}

if (isset($_POST['export_published'])) {
     ob_end_clean();//End previous buffer
    ob_start();// start new buffer for excel
    header("Content-Type: application/vnd.ms-excel");
    header("Content-Disposition: attachment; filename=published_papers.xls");

    // Write the Excel content header
    echo "Username\tBranch\tPaper Title\tJournal Name\tIndexing\tDate of Submission\tQuality Factor\tImpact Factor\tPayment\tSubmission Time\n";

    // Prepare and execute the SQL query
    $sql = "SELECT * FROM published_tab WHERE username = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();
    
    // Fetch and write data rows
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
           echo $row['username'] . "\t" . 
                $row['branch'] . "\t" .
                $row['paper_title'] . "\t" .
                $row['journal_name'] . "\t" .
                $row['indexing'] . "\t" .
                $row['date_of_submission'] . "\t" .
                $row['quality_factor'] . "\t" .
                $row['impact_factor'] . "\t" .
                $row['payment'] . "\t" .
                $row['submission_time'] . "\n";
        }
    }
      ob_end_flush();//End current buffer
    exit;
}
//--------------------------------------------------------------------------------------------------
// SQL query to fetch all records from the published_tab table
$sql_published = "SELECT * FROM published_tab WHERE username = ?";
$stmt_published = $conn->prepare($sql_published);
$stmt_published->bind_param("s", $username);
$stmt_published->execute();
$result_published = $stmt_published->get_result();

// Check if there are results
echo"<h2>Published Papers </h2>";?>
<form method="POST">
    <button type="submit" class="ex_bt" name="export_published">Export to Excel</button>
</form>
<?php
if ($result_published->num_rows > 0) {
    // Start the table and add headers
    echo "<div class='container11'>
            
            <table border='1'>
                <tr>
                    <th>Username</th>
                    <th>Branch</th>
                    <th>Paper Title</th>
                    <th>Journal Name</th>
                    <th>Indexing</th>
                    <th>Date of Submission</th>
                    <th>Quality Factor</th>
                    <th>Impact Factor</th>
                    <th>Payment</th>
                    <th>Submission Time</th>
                    <th>Paper</th>
                    <th>Action</th>
                </tr>";

    // Output data of each row
    while ($row = $result_published->fetch_assoc()) {
        $certificatePath = htmlspecialchars($row["paper_file"]);
           $deleteButton = "<form method='GET' action='' onsubmit='return confirm(\"Are you sure you want to delete this record?\")'>
                            <input type='hidden' name='delete_id' value='" . $row["id"] . "'>
                            <input type='hidden' name='table' value='published_tab'>    
                             <input type='hidden' name='file_column' value='paper_file'>
                            <input type='submit' id='del' value='Delete'>
                          </form>";

        echo "<tr>
                <td>" . $row["username"] . "</td>
                <td>" . $row["branch"] . "</td>
                <td>" . $row["paper_title"] . "</td>
                <td>" . $row["journal_name"] . "</td>
                <td>" . $row["indexing"] . "</td>
                <td>" . $row["date_of_submission"] . "</td>
                <td>" . $row["quality_factor"] . "</td>
                <td>" . $row["impact_factor"] . "</td>
                <td>" . $row["payment"] . "</td>
                <td>" . $row["submission_time"] . "</td>
                <td>
                    <a href='view_file1.php?file_path=" . urlencode($certificatePath) . "'><button id='view'>View</button></a><br><br>
                    <a href='" . htmlspecialchars($certificatePath) . "' download><button id='down'>Download</button></a>
                </td>
                <td>$deleteButton</td>
            </tr>";
    }
    // End the table
    echo "</table>
        </div>";
} else {
    echo "<p class='no-files'>No published papers found.</p>";
}

if (isset($_POST['export_conference'])) {
    ob_end_clean();//End previous buffer
    ob_start();// start new buffer for excel
    header("Content-Type: application/vnd.ms-excel");
    header("Content-Disposition: attachment; filename=conference_papers.xls");

    // Write the Excel content header
    echo "Username\tBranch\tPaper Title\tFrom Date\tTo Date\tOrganised By\tLocation\tPaper Type\tSubmission Time\n";

    // Prepare and execute the SQL query
    $sql = "SELECT * FROM conference_tab WHERE username = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();
    
    // Fetch and write data rows
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            echo $row['username'] . "\t" . 
            $row['branch'] . "\t" .
            $row['paper_title'] . "\t" .
            $row['from_date'] . "\t" .
            $row['to_date'] . "\t" .
            $row['organised_by'] . "\t" .
            $row['location'] . "\t" .
            $row['paper_type'] . "\t" .
            $row['submission_time'] . "\n";
        }
    }
      ob_end_flush();//End current buffer
    exit;
}
///------------------------------------------------------------------------------------------------------------
// SQL query to fetch all records from the conference_tab table
$sql_conference = "SELECT * FROM conference_tab WHERE username = ?";
$stmt_conference = $conn->prepare($sql_conference);
$stmt_conference->bind_param("s", $username);
$stmt_conference->execute();
$result_conference = $stmt_conference->get_result();

// Check if there are results
echo "<h2>Conference Papers</h2>";?>
<form method="POST">
    <button type="submit" class="ex_bt" name="export_conference">Export to Excel</button>
</form>
<?php
if ($result_conference->num_rows > 0) {
    // Start the table and add headers
    echo "<div class='container11'>
            <table border='1'>
                <tr>
                    <th>Username</th>
                    <th>Branch</th>
                    <th>Paper Title</th>
                    <th>From Date</th>
                    <th>To Date</th>
                    <th>Organised By</th>
                    <th>Location</th>
                    <th>Certificate</th>
                    <th>Paper Type</th>
                    <th>Paper File</th>
                    <th>Submission Time</th>
                    <th>Action</th>
                </tr>";

    // Output data of each row
    while ($row = $result_conference->fetch_assoc()) {
        $certificatePath = htmlspecialchars($row["certificate_path"]);
        $paperFilePath = htmlspecialchars($row["paper_file_path"]);
         $deleteButton = "<form method='GET' action='' onsubmit='return confirm(\"Are you sure you want to delete this record?\")'>
                            <input type='hidden' name='delete_id' value='" . $row["id"] . "'>
                            <input type='hidden' name='table' value='conference_tab'>
                             <input type='hidden' name='file_column' value='certificate_path'>
                            <input type='submit' id='del' value='Delete'>
                          </form>";
        if ($row["paper_type"] == "paper publication") {
            $paperFileButtons = "<a href='view_file1.php?file_path=" . urlencode($paperFilePath) . "'><button id='view'>View Paper</button></a>
                                 <a href='" . htmlspecialchars($paperFilePath) . "' download><button id='down'>Download Paper</button></a>";
        } else {
            $paperFileButtons = "No papers";
        }
       
        echo "<tr>
                <td>" . $row["username"] . "</td>
                <td>" . $row["branch"] . "</td>
                <td>" . $row["paper_title"] . "</td>
                <td>" . $row["from_date"] . "</td>
                <td>" . $row["to_date"] . "</td>
                <td>" . $row["organised_by"] . "</td>
                <td>" . $row["location"] . "</td>
                <td>
                    <a href='view_file1.php?file_path=" . urlencode($certificatePath) . "'><button id='view'>View </button></a><br><br>
                    <a href='" . htmlspecialchars($certificatePath) . "' download><button id='down'>Download </button></a>
                </td>
                <td>" . $row["paper_type"] . "</td>
                <td>$paperFileButtons</td>
                <td>" . $row["submission_time"] . "</td>
                <td>$deleteButton</td>
            </tr>";
    }
    // End the table
    echo "</table>
        </div>";
} else {
    echo "<p class='no-files'>No conference papers found.</p>";
}

if (isset($_POST['export_patent'])) {
    ob_end_clean();//End previous buffer
   ob_start();// start new buffer for excel
    header("Content-Type: application/vnd.ms-excel");
    header("Content-Disposition: attachment; filename=patents.xls");

    // Write the Excel content header
    echo "Username\tBranch\tPatent Title\tDate of Issue\tSubmission Time\n";

    // Prepare and execute the SQL query
    $sql = "SELECT * FROM patents_table WHERE username = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();
    
    // Fetch and write data rows
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            echo $row['Username'] . "\t" .
                $row['branch'] . "\t" .
                $row['patent_title'] . "\t" .
                $row['date_of_issue'] . "\t" .
                $row['submission_time'] . "\n";
        }
    }
       ob_end_flush();//End current buffer
    exit;
}
//------------------------------------------------------------------------------------------------------------
 // SQL query to fetch all records from the patents_table table
$sql_patents = "SELECT * FROM patents_table WHERE username = ?";
$stmt_patents = $conn->prepare($sql_patents);
$stmt_patents->bind_param("s", $username);
$stmt_patents->execute();
$result_patents = $stmt_patents->get_result();

// Check if there are results
echo "<h2>Patents</h2>";?>
<form method="POST">
    <button type="submit" class="ex_bt" name="export_patent">Export to Excel</button>
</form>
<?php
if ($result_patents->num_rows > 0) {
    // Start the table and add headers
    echo "<div class='container11'>
            <table border='1'>
                <tr>
                    <th>Username</th>
                    <th>Branch</th>
                    <th>Patent Title</th>
                    <th>Date of Issue</th>
                    <th>Patent File</th>
                    <th>Submission Time</th>
                    <th>Action</th>
                </tr>";

    // Output data of each row
    while ($row = $result_patents->fetch_assoc()) {
        $patentFilePath = htmlspecialchars($row["patent_file"]);
           $deleteButton = "<form method='GET' action='' onsubmit='return confirm(\"Are you sure you want to delete this record?\")'>
                            <input type='hidden' name='delete_id' value='" . $row["id"] . "'>
                            <input type='hidden' name='table' value='patents_table'>
                             <input type='hidden' name='file_column' value='patent_file'>
                            <input type='submit' id='del' value='Delete'>
                          </form>";

        // Check if patent_file exists
        if (!empty($patentFilePath)) {
             $patentFileButtons = "<a href='view_file1.php?file_path=" . urlencode($patentFilePath) . "'><button id='view'>View Patent</button></a>
                                 <a href='" . htmlspecialchars($patentFilePath) . "' download><button id='down'>Download Patent</button></a>";
        } else {
            $patentFileButtons = "No patent file";
        }

        echo "<tr>
                <td>" . $row["Username"] . "</td>
                <td>" . $row["branch"] . "</td>
                <td>" . $row["patent_title"] . "</td>
                <td>" . $row["date_of_issue"] . "</td>
                <td>$patentFileButtons</td>
                <td>" . $row["submission_time"] . "</td>
                <td>$deleteButton</td>
            </tr>";
    }
    // End the table
    echo "</table>
        </div>";
} else {
    echo "<p class='no-files'>No patents found.</p>";
}
ob_end_flush();
//-----------------------------------------------------------------------------------------------
// Close the connection
$conn->close();
?>
</div>
</body>
</html>