<?php
include("connection.php");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Initialize variables
// Initialize variables
$main_select = $_POST['main_select'] ?? '';
$papers_sub_select = $_POST['papers_sub_select'] ?? '';
$bodies_sub_select = $_POST['bodies_sub_select'] ?? '';
$branch_select = $_POST['branch_select'] ?? ''; // New branch variable

$records = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['submit_button']) || isset($_POST['export'])) {
        if ($main_select === 'Papers') {
            if ($papers_sub_select === 'Journals') {
                $query = "SELECT uploaded_by, branch, paper_title, journal_name, indexing, date_of_submission, quality_factor, 
                        impact_factor, payment, submission_time, paper_file  
                        FROM s_journal_tab 
                        WHERE branch = ?";
                $stmt = $conn->prepare($query);
                $stmt->bind_param("s", $branch_select);
                $stmt->execute();
                $result = $stmt->get_result();
                $records = $result->fetch_all(MYSQLI_ASSOC);
                $stmt->close();
            } elseif ($papers_sub_select === 'Conferences') {
                $query = "SELECT uploaded_by, branch, paper_title, from_date, to_date, organised_by, location, certificate_path, 
                        paper_type, paper_file_path, submission_time  
                        FROM s_conference_tab 
                        WHERE branch = ?";
                $stmt = $conn->prepare($query);
                $stmt->bind_param("s", $branch_select);
                $stmt->execute();
                $result = $stmt->get_result();
                $records = $result->fetch_all(MYSQLI_ASSOC);
                $stmt->close();
            }
        } elseif ($main_select === 'Professional Bodies') {
            $query = "SELECT Body, event_name, from_date, to_date, organised_by, location, participation_status, 
                        certificate_path, uploaded_by, branch, submission_time
                        FROM s_bodies 
                        WHERE Body = ? AND branch = ?";
            $stmt = $conn->prepare($query);
            $stmt->bind_param("ss", $bodies_sub_select, $branch_select);
            $stmt->execute();
            $result = $stmt->get_result();
            $records = $result->fetch_all(MYSQLI_ASSOC);
            $stmt->close();
        } else {
            if (isset($main_select) && !empty($main_select)) {
                $query = "SELECT activity, event_name, from_date, to_date, organised_by, location, participation_status, 
                            certificate_path, uploaded_by,branch , submission_time
                            FROM s_events 
                            WHERE activity = ? AND branch = ?";
                $stmt = $conn->prepare($query);
                $stmt->bind_param("ss", $main_select, $branch_select);
                $stmt->execute();
                $result = $stmt->get_result();
                $records = $result->fetch_all(MYSQLI_ASSOC);
                $stmt->close();
            } else {
                $records = [];
            }
        }
    }
}

function getHeadings($main_select, $sub_select = null) {
    if ($main_select === 'Papers') {
        if ($sub_select === 'Journals') {
            return ['ID', 'Uploaded By', 'Branch', 'Paper Title', 'Journal Name', 'Indexing', 'Date of Submission', 'Quality Factor', 'Impact Factor', 'Payment', 'Submission Time', 'Paper File'];
        } elseif ($sub_select === 'Conferences') {
            return ['ID', 'Uploaded By', 'Branch', 'Paper Title', 'From Date', 'To Date', 'Organised By', 'Location', 'Certificate', 'Paper Type', 'Paper File', 'Submission Time'];
        }
    } elseif ($main_select === 'Professional Bodies') {
        return ['ID', 'Body', 'Event Name', 'From Date', 'To Date', 'Organised By', 'Location', 'Participation Status', 'Certificate', 'Uploaded By', 'Branch', 'Submission Time'];
    } else {
        return ['ID', 'Activity', 'Event Name', 'From Date', 'To Date', 'Organised By', 'Location', 'Participation Status', 'Certificate', 'Uploaded By', 'Branch', 'Submission Time'];
    }
}

if (isset($_POST['export'])) {
    if (empty($records)) {
        die("No records to export.");
    }

    header("Content-Type: application/vnd.ms-excel");
    header("Content-Disposition: attachment; filename=data_export.xls");

    $excel_headings = getHeadings($main_select, $papers_sub_select);
    // Remove certificate and file columns from header for excel
    $keys_to_exclude = ['certificate_path', 'paper_file_path', 'paper_file'];
    $excel_headings = array_diff($excel_headings, $keys_to_exclude);

    echo implode("\t", $excel_headings) . "\n";

    $counter = 1;
    foreach ($records as $record) {
        $sanitized_record = [$counter++];
        foreach ($record as $key => $value) {
            if (!in_array($key, $keys_to_exclude)) {
                $sanitized_record[] = '"' . str_replace('"', '""', $value) . '"';
            }
        }
        echo implode("\t", $sanitized_record) . "\n";
    }
    exit;
}

?>

<?php
    include "./header.php";
    ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dynamic Data Display</title>
    <style>
         body {
            font-family: 'Poppins', sans-serif;
            margin: 0px;
            padding: 0;
            background: linear-gradient(to right, #74ebd5, #9face6);
            color: #333;
        }
        
        .container11 {
            max-width: 1400px;
            margin-left:40px;
            border-radius: 12px;
            box-shadow: 0 10px 20px rgba(0, 0, 0, 0.2);
            display: flex;
            flex-direction: column;
            align-items: center;
        }
        .div1{
            margin-top:100px;
            background: #fff;
            padding:30px;
            width: 1400px;
            margin-left:40px;
            border-radius: 12px;
            box-shadow: 0 10px 20px rgba(0, 0, 0, 0.2);
            display: flex;
            flex-direction: column;
            align-items: center;
        }
        h1 {
            text-align: center;
            margin-bottom: 20px;
            color: #444;
        }
        form {
            display: flex;
            flex-direction: column;
            gap: 15px;
        }
        label {
            font-weight: bold;
            font-size: 14px;
        }
        select{
            width:200px;
        }
        select, button {
            padding: 10px 15px;
            border: 1px solid #ccc;
            border-radius: 6px;
            font-size: 14px;
            box-shadow: inset 0 2px 4px rgba(0, 0, 0, 0.1);
        }
        select:focus, .btn11:focus {
            outline: none;
            border-color: #6a67ce;
        }
        .btn11 {
            background: linear-gradient(90deg, #6a67ce, #fc85ae);
            color: white;
            font-weight: bold;
            cursor: pointer;
            transition: all 0.3s ease;
            width: 100px;
            margin-left:100px;
        }
        .btn11:hover {
            background: linear-gradient(90deg, #fc85ae, #6a67ce);
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2);
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 30px;
        }
        table th, table td {
            padding: 10px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }
        table th {
            background: #6a67ce;
            color: white;
        }
        table tr:hover {
            background: #f9f9f9;
        }
        .no-data {
            text-align: center;
            margin-top: 20px;
            color: #ff0000;
        }
        .main_select_div{
            display: flex;
        }
        #l1{
            margin-top:10px ;
            margin-right: 20px;
        }
        .btn-container {
            display: flex;
            gap: 10px;
        }
        .btn-view, .btn-download {
            padding: 5px 15px;
            text-decoration: none;
            border-radius: 6px;
            color: white;
            font-weight: bold;
            cursor: pointer;
            transition: all 0.3s ease;
        }
        .btn-view {
            background: #6a67ce;
        }
        .btn-view:hover {
            background: #5555a5;
        }
        .btn-download {
            background: #4caf50;
        }
        .btn-download:hover {
            background: #45a049;
        }
        .no-file {
            color: #ff0000;
            font-style: italic;
        }
        .btn-export {
            display: <?= $_SERVER['REQUEST_METHOD'] === 'POST' && !empty($records) ? 'inline-block' : 'none' ?>;
            position: absolute;
            top: 20px;
            left: 500px;
            padding: 10px 20px;
            background-color:rgb(84, 209, 82);
            color: black;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            font-size: 14px;
            font-weight: bold;
        }
        .btn-export:hover {
            background-color: #45a049;
        }
    </style>
</head>
<body>
    
    <div class="container11">
    <div class="div1">
    <form method="POST" action="">
                <div class="main_select_div">
                    <label for="main-select" id="l1">Select Category:</label>
                    <select id="main-select" name="main_select">
                        <option value="" disabled selected>Choose an option</option>
                        <option value="Papers" <?= $main_select == 'Papers' ? 'selected' : '' ?>>Papers</option>
                        <option value="Projects" <?= $main_select == 'Projects' ? 'selected' : '' ?>>Projects</option>
                        <option value="Internships" <?= $main_select == 'Internships' ? 'selected' : '' ?>>Internships</option>
                        <option value="SIH" <?= $main_select == 'SIH' ? 'selected' : '' ?>>SIH</option>
                        <option value="Professional Bodies" <?= $main_select == 'Professional Bodies' ? 'selected' : '' ?>>Professional Bodies</option>
                    </select>
                </div>
                <div id="papers-sub-select-div" style="display: <?= $main_select == 'Papers' ? 'block' : 'none' ?>;">
                    <label for="papers-sub-select">Select Subcategory:</label>
                    <select id="papers-sub-select" name="papers_sub_select">
                        <option value="" disabled selected>Choose an option</option>
                        <option value="Journals" <?= $papers_sub_select == 'Journals' ? 'selected' : '' ?>>Journals</option>
                        <option value="Conferences" <?= $papers_sub_select == 'Conferences' ? 'selected' : '' ?>>Conferences</option>
                    </select>
                </div>
                <div id="bodies-sub-select-div" style="display: <?= $main_select == 'Professional Bodies' ? 'block' : 'none' ?>;">
                    <label for="bodies-sub-select">Select Subcategory:</label>
                    <select id="bodies-sub-select" name="bodies_sub_select">
                        <option value="" disabled selected>Choose an option</option>
                        <option value="ISTE" <?= $bodies_sub_select == 'ISTE' ? 'selected' : '' ?>>ISTE</option>
                        <option value="CSI" <?= $bodies_sub_select == 'CSI' ? 'selected' : '' ?>>CSI</option>
                        <option value="ACM" <?= $bodies_sub_select == 'ACM' ? 'selected' : '' ?>>ACM</option>
                        <option value="ACMW" <?= $bodies_sub_select == 'ACMW' ? 'selected' : '' ?>>ACMW</option>
                        <option value="Coding Club" <?= $bodies_sub_select == 'Coding Club' ? 'selected' : '' ?>>Coding Club</option>
                    </select>
                </div>
                <div>
                    <label for="branch-select">Select Branch:</label>
                    <select id="branch-select" name="branch_select">
                        <option value="" disabled selected>Choose an option</option>
                        <option value="CSE" <?= $branch_select == 'CSE' ? 'selected' : '' ?>>CSE</option>
                        <option value="AIML" <?= $branch_select == 'AIML' ? 'selected' : '' ?>>AIML</option>
                        <option value="AIDS" <?= $branch_select == 'AIDS' ? 'selected' : '' ?>>AIDS</option>
                        <option value="IT" <?= $branch_select == 'IT' ? 'selected' : '' ?>>IT</option>
                        <option value="ECE" <?= $branch_select == 'ECE' ? 'selected' : '' ?>>ECE</option>
                        <option value="EEE" <?= $branch_select == 'EEE' ? 'selected' : '' ?>>EEE</option>
                        <option value="MECH" <?= $branch_select == 'MECH' ? 'selected' : '' ?>>MECH</option>
                        <option value="CIVIL" <?= $branch_select == 'CIVIL' ? 'selected' : '' ?>>CIVIL</option>
                        <option value="BSH" <?= $branch_select == 'BSH' ? 'selected' : '' ?>>BSH</option>
                    </select>
                </div>
                <div class="btn-div">
                    <button type="submit" class="btn11" name="submit_button">Submit</button>
                </div>
            </form>
    <div class="container111">
        <table id="data-table">
            <thead>
                <tr>
                    <?php
                        $headings = getHeadings($main_select, $papers_sub_select);
                        foreach ($headings as $heading) {
                            echo "<th>$heading</th>";
                        }
                    ?>
                </tr>
            </thead>
            <tbody>
                    <?php if (empty($records)) : ?>
                        <tr>
                            <td colspan="<?= count($headings) + 1; ?>" class="no-data">No data available for the selected criteria.</td>
                        </tr>
                    <?php else : ?>
                        <?php 
                        $counter = 1; // Initialize the counter
                        foreach ($records as $record) : ?>
                            <tr>
                                <td><?= $counter++; ?></td> <!-- Display the incremented ID -->
                                <?php
                                foreach ($record as $key => $value) {
                                    if ($key == 'paper_file' || $key == 'certificate_path' || $key == 'paper_file_path') {
                                        if (empty($value)) {
                                            echo "<td><span class='no-file'>No File</span></td>";
                                        } else {
                                            echo "<td class='btn-container'>
                                                    <a href='$value' target='_blank' class='btn-view'>View</a>
                                                    <a href='$value' download class='btn-download'>Download</a>
                                                </td>";
                                        }
                                    } else {
                                        echo "<td>$value</td>";
                                    }
                                }
                                ?>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>


        </table>
    </div>
</div>
</div>
<script>
    const mainSelect = document.getElementById('main-select');
    const papersSubSelectDiv = document.getElementById('papers-sub-select-div');
    const bodiesSubSelectDiv = document.getElementById('bodies-sub-select-div');
    
    mainSelect.addEventListener('change', function() {
        if (mainSelect.value === 'Papers') {
            papersSubSelectDiv.style.display = 'block';
            bodiesSubSelectDiv.style.display = 'none';
        } else if (mainSelect.value === 'Professional Bodies') {
            bodiesSubSelectDiv.style.display = 'block';
            papersSubSelectDiv.style.display = 'none';
        } else {
            papersSubSelectDiv.style.display = 'none';
            bodiesSubSelectDiv.style.display = 'none';
        }
    });
</script>
</body>
</html>