<?php
    include './header.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>TechCorp - Contact Us</title>
    <link rel="stylesheet" href="./css/acd_year1.css">
</head>
<body>
    <main class="hero">
        <div class="container">
            <div class="contact-wrapper">
                <!-- AQARs Supporting Documents Section -->
                <div class="contact-form">
                    <h1>AQARs Supporting Documents</h1>
                    <form action="criteria.php" method="POST">
                        <div class="form-group">
                            <label for="academic-year">Select Academic Year:</label>
                            <select name="year" id="academic-year" required>
                                <option value="" disabled selected>Select an academic year</option>
                                <option value="2022-23">2022-23</option>
                                <option value="2021-22">2021-22</option>
                                <option value="2020-21">2020-21</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="criteria">Select Criteria:</label>
                            <select name="criteria" id="criteria" required>
                                <option value="" disabled selected>Select a criteria</option>
                                <option value="1">1</option>
                                <option value="2">2</option>
                                <option value="3">3</option>
                                <option value="4">4</option>
                                <option value="5">5</option>
                                <option value="6">6</option>
                                <option value="7">7</option>
                            </select>
                        </div>
                        <button type="submit" class="button1">Enter</button>
                    </form>
                </div>

                <!-- Achievements Section -->
                <div class="contact-form">
                    <div class="content">
                        <h1>Achievements</h1>
                        <a href="download_papers.php" class="btn my-achievements">My Achievements</a>
                        <div class="buttons">
                            <a href="fdps.php" class="btn fdps">FDPS Attended</a><br><br><br>
                            <a href="fdps_org.php" class="btn fdps">FDPS Organized</a><br><br><br>
                            <a href="published.php" class="btn  fdps papers">Papers Published</a><br><br><br>
                            <a href="conference.php" class="btn fdps  papers">Conferences Published</a><br><br><br>
                            <a href="patents.php" class="btn fdps  patents">Patents</a>
                        </div>
                    </div>
                </div>

                <!-- Department Files Section -->
                <div class="contact-form">
                    
                    <h1>Department Files</h1>
                    <a href="dept_down_files.php" class="btn my-dept-files">My Dept Files</a>
                    <div class="buttons1">
                        <a href="dept_files.php?event=admin" class="btn admin-files">Admin Files</a><br><br><br>
                        <a href="dept_files.php?event=faculty" class="btn faculty-files">Faculty Files</a><br><br><br>
                        <a href="dept_files.php?event=student" class="btn student-files">Student Files</a><br><br><br>
                        <a href="dept_files.php?event=exam" class="btn exam-files">Exam Section Files</a>
                    </div>
                </div>
            </div>
        </div>
    </main>
</body>
</html>
