// JavaScript to show/hide the paper file input based on the selected paper type

