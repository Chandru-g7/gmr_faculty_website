<?php
session_start(); // Start session
include 'header.php'; // Include the header
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>FMS</title>
    <link rel="stylesheet" href="./css/index.css">
</head>
<body>
    <main class="hero">
        <div class="container">
            <div class="hero-content">
                <?php
                    // Check if the user is logged in
                    if (isset($_SESSION['username'])) {
                        // Logout logic when button is clicked?>
                        <a href="./edit_profile.php"><button class="btn1-outline1">Edit Profile</button></a><?php
                        if (isset($_POST['logout'])) {
                            session_unset();  // Unset all session variables
                            session_destroy(); // Destroy the session
                            echo"<script>alert('YOU successfully loged out'); window.location.href='index.php';</script>"; // Redirect to the login page"
                            
                        }
                        // Display the logout button if the user is logged in
                        echo '<form method="POST">
                                <button type="submit" name="logout" class="logout-btn1">Logout</button>
                              </form>';
                    } 

                ?>
                
                
                <a href="./pdf_merger.php"><button class="btn1-outline2">Pdf Merger</button></a>
                <h2>Welcome to GMRIT</h2>
                <h1>File Management System</h1>
                
                <div class="description">
                    <p>
                    This is a user-friendly platform designed to store, organize, and manage files efficiently. It allows users to upload, search, retrieve, and share files securely with role-based access controls. Simplify file handling with our intuitive and reliable solution. Designed for efficiency and collaboration, it ensures data protection and easy accessibility.
                    </p>
                </div>
                
                <div class="buttons">
                    <a href="central_events.php"><button class="btn btn-outline1">Central</button></a>
                    <a href="./department.php"><button class="btn btn-outline1">Department</button></a>
                </div>
                
            </div>
        </div>
    </main>
</body>
</html>
