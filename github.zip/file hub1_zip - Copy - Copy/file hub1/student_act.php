<?php
    include 'header.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Central Events</title>
    <style>
        body {
            background-image: url('./stuff/gmr_landing_page.jpg');
            background-size: cover;
            background-position: center;
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            color: #fff;
        }

        body::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 110vh;
            background: rgba(0, 0, 0, 0.5);
            z-index: -1;
        }

        .container {
            margin-top: 150px;
            text-align: center;
            background: rgba(0, 0, 0, 0.7);
            padding: 40px;
            border-radius: 15px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.6);
            margin-bottom: 50px;
        }

        h1 {
            color: #fff;
            margin-bottom: 20px;
            font-size: 2.5em;
            text-transform: uppercase;
            letter-spacing: 2px;
        }

        .button-container {
            display: grid;
            gap: 30px;
        }
        
        .button {
            background: linear-gradient(to right,rgb(139, 10, 130),rgb(229, 129, 225));
            border: none;
            padding: 10px 15px;
            font-size: 1em;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s, transform 0.2s;
            text-decoration: none;
            color: white;
            text-align: center;
        }

        .button:hover {
            transform: translateY(-3px);
        }

        .button:active {
            transform: translateY(0);
        }

        .button1 {
            position:absolute;
            top:150px;
            right:300px;
            background: linear-gradient(to right,rgb(2, 26, 48),rgb(129, 187, 229));
            border: none;
            padding: 10px 15px;
            font-size: 1em;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s, transform 0.2s;
            text-decoration: none;
            color: white;
            text-align: center;
            width:100px;
        }

        .button1:hover {
            background: linear-gradient(to right,rgb(122, 199, 232),rgb(4, 20, 51));
            transform: translateY(-3px);
        }

        .button1:active {
            transform: translateY(0);
        }
        

    </style>
</head>
<body>
<a href="s_down_files.php?" id="bt" class="button1">Uploads</a>
<div class="container">
    <h1>Student Activities</h1>
    <div class="button-container">
        <a href="s_login.php?activity=Papers" class="button">Papers</a>
        <a href="s_login.php?activity=Projects" class="button">Projects</a>
        <a href="s_login.php?activity=Internships" class="button">Internships</a>
        <a href="s_login.php?activity=SIH" class="button">SIH</a>
        <a href="s_login.php?activity=GATE" class="button">GATE</a>
        <a href="s_login.php?activity=Hackathons" class="button">Hackathons</a>
        <a href="s_login.php?activity=Professional_Bodies" class="button">Professional Bodies</a>
    </div>
</div>

</body>
</html>
