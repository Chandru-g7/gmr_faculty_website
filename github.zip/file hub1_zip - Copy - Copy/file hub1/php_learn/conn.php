<php
    $con=mysqli_connect("localhost","chandu","123","chandu_db");
    if($con){
        echo "connection is successfull";
    }
?>