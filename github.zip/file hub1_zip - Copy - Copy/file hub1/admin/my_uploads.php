<?php
include("connection.php");
session_start();

if (!isset($_SESSION['username'])) {
    die("You need to log in to view your uploads.");
}



$username = $_SESSION['username'];

// Handle Excel Download
if (isset($_POST['download_excel'])) {
    header('Content-Type: application/vnd.ms-excel');
    header('Content-Disposition: attachment;filename="my_uploads.xls"');
    header('Cache-Control: max-age=0');
    
    // Output Excel Headers
    echo "ID\tUsername\tFaculty Name\tAcademic Year\tFilename\tUploaded At\tCriteria No\n";
    
    $sql = "SELECT * FROM a_files WHERE username = ? ORDER BY uploaded_at DESC";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();
    
    $id = 1;
    while ($row = $result->fetch_assoc()) {
        $uploadedAt = new DateTime($row['uploaded_at']);
        $formattedDateTime = $uploadedAt->format('Y/m/d H:i:s');
        
        echo $id . "\t";
        echo $row['username'] . "\t";
        echo $row['Faculty_name'] . "\t";
        echo $row['academic_year'] . "\t";
        echo $row['file_name'] . "\t";
        echo $formattedDateTime . "\t";
        echo $row['criteria'] . "\n";
        
        $id++;
    }
    exit();
}
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $academicYear = htmlspecialchars($_POST['academic_year']);
    $criteria = htmlspecialchars($_POST['criteria']);
} else {
    echo "<p>No academic year or criteria was selected.</p>";
    exit;
}
include 'header_admin.php';
// Handle file deletion
if (isset($_GET['delete'])) {
    $fileId = intval($_GET['delete']);

    // Fetch the file details
    $sql = "SELECT file_path FROM a_files WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $fileId);
    $stmt->execute();
    $result = $stmt->get_result();
    $file = $result->fetch_assoc();

    if ($file) {
        if (unlink($file['file_path'])) {
            $sql = "DELETE FROM a_files WHERE id = ?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("i", $fileId);
            $stmt->execute();
        } else {
            echo "<p class='error-message'>Error deleting the file.</p>";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Uploads</title>
    <style>
        :root {
            --primary-color: #2563eb;
            --secondary-color: #1e40af;
            --success-color: #16a34a;
            --danger-color: #dc2626;
            --background-color: #f1f5f9;
            --card-background: #ffffff;
            --text-primary: #1e293b;
            --text-secondary: #64748b;
            --border-color: #e2e8f0;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            margin: 0;
            padding: 0;
            background-color: var(--background-color);
            color: var(--text-primary);
        }

        .container11 {
            margin: 0px auto 40px;
            max-width: 1300px;
            padding: 30px;
            background: var(--card-background);
            border-radius: 16px;
            box-shadow: 0 4px 6px -1px rgb(0 0 0 / 0.1), 0 2px 4px -2px rgb(0 0 0 / 0.1);
        }

        .header-section {
            margin-top:70px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
        }

        h1 {
            margin: 0;
            color: var(--text-primary);
            font-size: 2.25rem;
            font-weight: 700;
        }

        .download-excel {
            background-color: var(--primary-color);
            color: white;
            padding: 12px 24px;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            font-weight: 600;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .download-excel:hover {
            background-color: var(--secondary-color);
            transform: translateY(-1px);
            box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
        }

        table {
            width: 100%;
            border-collapse: separate;
            border-spacing: 0;
            margin: 20px 0;
            border-radius: 8px;
            overflow: hidden;
        }

        th, td {
            text-align: left;
            padding: 16px;
            border: 1px solid var(--border-color);
        }

        th {
            background-color: var(--primary-color);
            color: white;
            font-weight: 600;
            text-transform: uppercase;
            font-size: 0.875rem;
            letter-spacing: 0.05em;
        }

        tr:nth-child(even) {
            background-color: #f8fafc;
        }

        tr:hover {
            background-color: #f1f5f9;
        }

        button {
            border: none;
            border-radius: 6px;
            padding: 8px 16px;
            font-size: 0.875rem;
            cursor: pointer;
            font-weight: 600;
            transition: all 0.2s ease;
        }

        button#view {
            background-color: var(--success-color);
            color: white;
        }

        button#view:hover {
            filter: brightness(110%);
            transform: translateY(-1px);
        }

        button#down {
            background-color: var(--primary-color);
            color: white;
        }

        button#down:hover {
            filter: brightness(110%);
            transform: translateY(-1px);
        }

        button#del {
            background-color: var(--danger-color);
            color: white;
        }

        button#del:hover {
            filter: brightness(110%);
            transform: translateY(-1px);
        }

        .no-files {
            text-align: center;
            color: var(--text-secondary);
            font-style: italic;
            padding: 24px;
        }

        .error-message {
            background-color: #fee2e2;
            color: var(--danger-color);
            padding: 12px;
            border-radius: 6px;
            margin: 16px 0;
            text-align: center;
        }

        /* Responsive Design */
        @media (max-width: 1024px) {
            .container11 {
                margin: 80px 20px 40px;
                padding: 20px;
            }
        }

        @media (max-width: 768px) {
            table {
                display: block;
                overflow-x: auto;
                white-space: nowrap;
            }

            .header-section {
                flex-direction: column;
                gap: 16px;
            }

            h1 {
                font-size: 1.875rem;
            }
        }
    </style>
</head>
<body>
    <div class="container11">

        <div class="header-section">
            <h1>My Uploads</h1>
            <form method="POST">
                <button type="submit" name="download_excel" class="download-excel">
                    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/>
                        <polyline points="7 10 12 15 17 10"/>
                        <line x1="12" y1="15" x2="12" y2="3"/>
                    </svg>
                    Download Excel
                </button>
            </form>
        </div>

        <table>
            <tr>
                <th>ID</th>
                <th>Username</th>
                <th>Faculty Name</th>
                <th>Academic Year</th>
                <th>Filename</th>
                <th>Uploaded At</th>
                <th>Criteria No</th>
                <th>View</th>
                <th>Download</th>
                <th>Delete</th>
            </tr>
            <?php
            if ($conn->connect_error) {
                die("Connection failed: " . $conn->connect_error);
            }

            $sql = "SELECT * FROM a_files WHERE username = ? ORDER BY uploaded_at DESC";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("s", $username);
            $stmt->execute();
            $result = $stmt->get_result();

            if ($result->num_rows > 0) {
                $id = 1;
                while ($row = $result->fetch_assoc()) {
                    $uploadedAt = new DateTime($row['uploaded_at']);
                    $formattedDateTime = $uploadedAt->format('Y/m/d') . ' & ' . $uploadedAt->format('H:i:s');

                    echo "<tr>";
                    echo "<td>" . $id . "</td>";
                    echo "<td>" . htmlspecialchars($_SESSION['username']) . "</td>";
                    echo "<td>" . htmlspecialchars($row['Faculty_name']) . "</td>";
                    echo "<td>" . htmlspecialchars($row['academic_year']) . "</td>";
                    echo "<td>" . htmlspecialchars($row['file_name']) . "</td>";
                    echo "<td>" . $formattedDateTime . "</td>";
                    echo "<td>" . htmlspecialchars($row['criteria']) . "</td>";
                    echo "<td><a href='" . htmlspecialchars($row['file_path']) . "' target='_blank'><button id='view'>View</button></a></td>";
                    echo "<td><a href='" . htmlspecialchars($row['file_path']) . "' download><button id='down'>Download</button></a></td>";
                    echo "<td><a href='?delete=" . htmlspecialchars($row['id']) . "' onclick=\"return confirm('Are you sure you want to delete this file?');\"><button id='del'>Delete</button></a></td>";
                    echo "</tr>";
                    $id++;
                }
            } else {
                echo "<tr><td colspan='10' class='no-files'>No files found</td></tr>";
            }

            $conn->close();
            ?>
        </table>
    </div>
</body>
</html>