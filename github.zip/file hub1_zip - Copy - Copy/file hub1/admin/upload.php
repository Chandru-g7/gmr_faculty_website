<?php
include("connection.php");
session_start();

if (!isset($_SESSION['username'])) {
    die("You need to log in to view your uploads.");
}

// Get the academic year, criteria, and criteria number from the POST request
$academic_year = isset($_POST['academic_year']) ? $_POST['academic_year'] : '';
$criteria = isset($_POST['criteria']) ? $_POST['criteria'] : '';
$criteria_no = isset($_POST['criteria_no']) ? $_POST['criteria_no'] : '';

date_default_timezone_set('Asia/Kolkata');

if (isset($_POST['upload'])) {
    // Retrieve the username from the session
    $username = $_SESSION['username'];
    $faculty_name = $_POST['faculty_name'];
    $filename = $_POST['file_name'];
    $targetDir = "uploads1/";
    $currentDateTime = date('Y-m-d H:i:s');
    $criteria = $_POST['criteria'];
    $academic_year = $_POST['academic_year'];


    // Create directory if it doesn't exist
    if (!is_dir($targetDir)) {
        mkdir($targetDir, 0777, true);
    }

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    $uploadSuccess = false;
    foreach ($_FILES['files']['name'] as $key => $file_name) {
        $filepath = $targetDir . basename($file_name);

        if (move_uploaded_file($_FILES['files']['tmp_name'][$key], $filepath)) {
            // Use prepared statements to prevent SQL injection
            $sql = "INSERT INTO a_files (username, academic_year, criteria, uploaded_at, Faculty_name, file_name, file_path) 
                    VALUES (?, ?, ?, ?, ?, ?, ?)";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("sssssss", $username, $academic_year, $criteria, $currentDateTime, $faculty_name, $filename, $filepath);

            if ($stmt->execute()) {
                $uploadSuccess = true;
            } else {
                echo "Error: " . $stmt->error;
            }
        } else {
            echo "<p class='error-message'>Error moving uploaded file: $filename</p>";
        }
    }

    $stmt->close();
    $conn->close();
    if ($uploadSuccess) {
        echo "<script>alert('File(s) uploaded successfully.');</script>";
    }
}
?>

<?php 
include 'header_admin.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>File Upload</title>
    <link rel='stylesheet' href="../css/upload_a1.css">
</head>
<body>
    

    <div class="upload-container">
        <h1>Upload Files</h1>
        <form action="upload.php" method="POST" enctype="multipart/form-data" onsubmit="return validateForm()">
            <!-- Hidden fields for academic_year, criteria, and criteria_no -->
            <input type="hidden" name="academic_year" id="academic_year" value="<?php echo $academic_year; ?>">
            <input type="hidden" name="criteria" id="criteria" value="<?php echo $criteria; ?>">
            <input type="hidden" name="criteria_no" id="criteria_no" value="<?php echo $criteria_no; ?>">

            <label for="faculty_name">Faculty Name:</label>
            <input type="text" id="faculty_name" name="faculty_name" required>

            <label for="file_name">File Name:</label>
            <input type="text" id="file_name" name="file_name" required>

            <label for="file">Choose files to upload:</label>
            <input type="file" id="file" name="files[]" multiple required>

            <button type="submit" name="upload" id='but'>Upload</button>
        </form>

    </div>

</body>
<script>

    function validateForm() {
        var academic_year = document.getElementById('academic_year').value;
        var criteria = document.getElementById('criteria').value;
        var criteria_no = document.getElementById('criteria_no').value;

        if (academic_year === '' || criteria === '' || criteria_no === '') {
            alert('Please fill out the academic year, criteria, and criteria number.');
            return false; // Prevent form submission
        }

        return true; // Proceed with form submission if validation passes
    }
</script>
</html>
