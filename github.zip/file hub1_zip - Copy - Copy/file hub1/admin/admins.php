<?php
include 'header_admin.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>FMS</title>
    <link rel="stylesheet" href="../css/index.css">
    <link rel="stylesheet" href="../css/admins.css">
</head>
<body>
    <main class="hero">
    <div class="container">
        
        <div class="button-container">
        <h1>Choose your login:</h1>
            <button onclick="location.href='../login.php'"         class="btn1">Faculty Login</button><br>
            <button onclick="location.href='dept_co_lg.php'"       class="btn1">Dept Coordinate Login</button><br>
            <button onclick="location.href='../HOD/HOD_lg.php'"     class="btn1">HOD Login</button><br>
            <button onclick="location.href='../HOD/cen_co_lg.php'"     class="btn1">Central Coordinate Login</button><br>
            <button onclick="location.href='../HOD/main_admin.php'"     class="btn1">Admin Login</button>
            <h4>Don't have an account? please <a href="../reg.php">register</a> here ...</h4>
        </div>
    </div>
    </main>

 
</body>
</html>


