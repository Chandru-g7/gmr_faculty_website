<?php
include 'connection.php'; // Include database connection

// Set timezone to Indian Standard Time
date_default_timezone_set('Asia/Kolkata');

if (isset($_GET['activity'])) {
    $activity = urldecode($_GET['activity']); // Decode the activity
} else {
    $activity = 'Unknown'; // Fallback if no activity is provided
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $event_name = $_POST['event_name'];
    $from_date = $_POST['from_date'];
    $to_date = $_POST['to_date'];
    $organised_by = $_POST['organised_by'];
    $location = $_POST['location'];
    $participation_status = $_POST['participation_status'];
    $uploaded_by = $_POST['uploaded_by'];
    $Branch = $_POST['Branch'];

    // Handle certificate upload
    $certificate_path = '';
    if (isset($_FILES['certificate']) && $_FILES['certificate']['error'] == 0) {
        $certificate_path = 'uploads/' . basename($_FILES['certificate']['name']);
        move_uploaded_file($_FILES['certificate']['tmp_name'], $certificate_path);
    }
    date_default_timezone_set('Asia/Kolkata');
    $submission_time = date('d-m-Y H:i:s');
    // Insert into database
    $stmt = $conn->prepare("INSERT INTO s_events (activity, event_name, from_date, to_date, organised_by, location, participation_status, certificate_path, uploaded_by, Branch, submission_time) 
                            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?,?)");
    $stmt->bind_param("sssssssssss",$activity, $event_name, $from_date, $to_date, $organised_by, $location, $participation_status, $certificate_path, $uploaded_by, $Branch, $submission_time);

    if ($stmt->execute()) {
        echo "<script>alert('Event submitted successfully!');</script>";
    } else {
        echo "<script>alert('Error: " . addslashes($stmt->error) . "');</script>";
    }

    $stmt->close();
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Event Submission</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            height: 100%;
            background-image: url('./stuff/gmr_landing_page.jpg');
            background-size: cover;
            background-position: center;
        }
        body::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 150%;
            background: rgba(0, 0, 0, 0.5); /* Adjust the opacity as needed */
            z-index: -1;
        }

        .cont11 {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        .form-container {
            margin-top:50vh;
            background-color: rgb(245, 240, 240,0.7);
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1);
            max-width: 600px;
            width: 100%;
            padding: 20px;
            border-radius: 10px;
        }

        .form-container h1 {
            text-align: center;
            color: #333;
            margin-bottom: 20px;
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-group label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
            color: #555;
        }

        .form-group input, 
        .form-group select {
            width: 90%;
            padding: 10px;
            margin: 5px 0;
            border: 1px solid #ccc;
            border-radius: 5px;
            font-size: 14px;
        }
        .form-group input[type="file"] {
            background-color: white;
            color:black;
        }

        .form-group input:focus, 
        .form-group select:focus {
            border-color: #4CAF50;
            outline: none;
        }

        .form-group button {
            width: 100%;
            padding: 12px;
            background-color: #4CAF50;
            color: white;
            border: none;
            border-radius: 5px;
            font-size: 16px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        .form-group button:hover {
            background-color: #45a049;
        }

        @media screen and (max-width: 768px) {
            .form-container {
                margin: 20px;
                padding: 15px;
            }

            .form-group input, 
            .form-group select {
                font-size: 13px;
            }

            .form-group button {
                font-size: 14px;
            }
        }

    </style>
</head>
<?php 
    include "header.php";
?>
<body>
    <div class="cont11">

<div class="form-container">
    <h1>Event Submission</h1>
    <form method="POST" enctype="multipart/form-data">
        <div class="form-group">
            <label for="event_name">Name of the Event:</label>
            <input type="text" id="event_name" name="event_name" required>
        </div>
        <div class="form-group">
            <label for="from_date">From Date:</label>
            <input type="date" id="from_date" name="from_date" required>
        </div>
        <div class="form-group">
            <label for="to_date">To Date:</label>
            <input type="date" id="to_date" name="to_date" required>
        </div>
        <div class="form-group">
            <label for="organised_by">Organised By:</label>
            <input type="text" id="organised_by" name="organised_by" required>
        </div>
        <div class="form-group">
            <label for="location">Location:</label>
            <input type="text" id="location" name="location" required>
        </div>
        <div class="form-group">
            <label for="participation_status">Participation Status:</label>
            <select id="participation_status" name="participation_status" required>
                <option value="Participated">Participated</option>
                <option value="1st">1st</option>
                <option value="2nd">2nd</option>
                <option value="3rd">3rd</option>
            </select>
        </div>
        <div class="form-group">
            <label for="certificate">Certificate:</label>
            <input type="file" id="certificate" name="certificate">
        </div>
        <div class="form-group">
            <label for="uploaded_by">Uploaded By:</label>
            <input type="text" id="uploaded_by" name="uploaded_by" required>
        </div>
        <div class="form-group">
            <label for="participation_status">Branch:</label>
            <select id="participation_status" name="Branch" required>
                <option value="" selected disabled>Choose one</option>
                <option value="CSE">CSE</option>
                <option value="AIML">AIML</option>
                <option value="AIDS">AIDS</option>
                <option value="IT">IT</option>
                <option value="ECE">ECE</option>
                <option value="EEE">EEE</option>
                <option value="MECH">MECH</option>
                <option value="CIVIL">CIVIL</option>
                <option value="BSH">BSH</option>
            </select>
        </div>
        <div class="form-group">
            <button type="submit">Submit</button>
        </div>
    </form>
</div>
</div>
</body>
</html>

