<?php
include("connection.php");
session_start();

if (!isset($_SESSION['username'])) {
    die("You need to log in to view your uploads.");
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $user = $_SESSION['username'];

    // Fetch user's branch
    $branch_query = "SELECT dept FROM reg_tab WHERE userid = '$user'";
    $branch_result = $conn->query($branch_query);

    if ($branch_result && $branch_result->num_rows > 0) {
        $branch_row = $branch_result->fetch_assoc();
        $branch = $branch_row['dept'];
    } else {
        die("Branch not found for the user.");
    }

    // Form data
    $title = mysqli_real_escape_string($conn, $_POST['title']);
    $date_from = mysqli_real_escape_string($conn, $_POST['date_from']);
    $date_to = mysqli_real_escape_string($conn, $_POST['date_to']);
    $organised_by = mysqli_real_escape_string($conn, $_POST['organised_by']);
    $location = mysqli_real_escape_string($conn, $_POST['location']);

    // File uploads
    $uploads_dir = "uploads/certificates/";

    function uploadFile($file_key, $uploads_dir) {
        if (!empty($_FILES[$file_key]['name'])) {
            $file_name = basename($_FILES[$file_key]['name']);
            $target_file = $uploads_dir . $file_name;

            // Handle special characters
            $file_name = mysqli_real_escape_string($GLOBALS['conn'], $file_name);

            if (move_uploaded_file($_FILES[$file_key]['tmp_name'], $target_file)) {
                return $target_file;
            } else {
                die("Error uploading file: " . $file_key);
            }
        }
        return null;
    }

    $certificate = uploadFile('certificate', $uploads_dir);
    $brochure = uploadFile('Brochure', $uploads_dir);
    $fdp_schedule_invitation = uploadFile('fdp_s_i', $uploads_dir);
    $attendance_forms = uploadFile('attendence', $uploads_dir);
    $feedback_forms = uploadFile('feedback', $uploads_dir);
    $fdp_report = uploadFile('report', $uploads_dir);
    $photo1 = uploadFile('Photo1', $uploads_dir);
    $photo2 = uploadFile('Photo2', $uploads_dir);
    $photo3 = uploadFile('Photo3', $uploads_dir);

    // Submission time
    date_default_timezone_set('Asia/Kolkata');
    $submission_time = date('Y-m-d H:i:s');

    // SQL Insert Query
    $sql = "INSERT INTO fdps_org_tab (username, branch, title, date_from, date_to, organised_by, location, certificate, brochure, fdp_schedule_invitation, attendance_forms, feedback_forms, fdp_report, photo1, photo2, photo3, submission_time)
            VALUES ('$user', '$branch', '$title', '$date_from', '$date_to', '$organised_by', '$location', '$certificate', '$brochure', '$fdp_schedule_invitation', '$attendance_forms', '$feedback_forms', '$fdp_report', '$photo1', '$photo2', '$photo3', '$submission_time')";

    if ($conn->query($sql) === TRUE) {
        echo "<script>alert('Records uploaded successfully');</script>";
        echo "<script>window.location.href = 'acd_year.php';</script>";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

include 'header.php';
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Event Details Form</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Arial', sans-serif;
            background-image: url('./stuff/gmr_landing_page.jpg');
            background-size: cover;
            background-position: center;
            display: flex;
            justify-content: center;
            height: 105vh;
            margin: 0;
        }

        body::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 200%;
            background: rgba(0, 0, 0, 0.5); /* Adjust overlay opacity */
            z-index: -1;
        }

        .container {
            margin-top: 100px;
            margin-bottom: 50px;
            background-color: rgba(0, 0, 0, 0.7);
            padding: 40px;
            border-radius: 12px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.5);
            width: 600px;
            max-width: 100%;
            height: 170%;
            color: white;
        }

        h1 {
            text-align: center;
            font-size: 2.5rem;
            font-weight: 600;
            margin-bottom: 20px;
            color:rgb(250, 132, 205);
            letter-spacing: 1px;
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-group label {
            font-size: 16px;
            font-weight: 600;
            display: block;
            margin-bottom: 5px;
        }

        .form-group input,
        .form-group select {
            width: 100%;
            padding: 12px;
            font-size: 16px;
            border-radius: 8px;
            border: 0.2px solid rgb(165, 225, 239);
            background-color: #1c1c1c;
            color: white;
        }

        .form-group input:focus,
        .form-group select:focus {
            outline: none;
            border-color: #84fab0;
        }

        .btn1 {
            padding: 15px;
            font-size: 18px;
            background-color: #84fab0;
            color: black;
            border: none;
            border-radius: 10px;
            cursor: pointer;
            width: 100%;
            font-weight: bold;
            transition: background-color 0.3s ease, transform 0.2s ease;
        }

        .btn1:hover {
            background-color: #4ca1af;
        }

        .btn1:active {
            transform: scale(0.98);
        }

        .back-button {
            position: absolute;
            top: 20px;
            left: 20px;
            padding: 12px 20px;
            background-color: #e74c3c;
            color: white;
            border: none;
            border-radius: 10px;
            cursor: pointer;
            font-size: 18px;
            transition: background-color 0.3s ease;
        }

        .back-button:hover {
            background-color: #c0392b;
        }

        @media (max-width: 768px) {
            .container {
                padding: 20px;
                width: 90%;
            }
            h1 {
                font-size: 2rem;
            }
        }
    </style>
</head>
<body>

<div class="container">
    <h1>FDPS organised Form</h1>
    <form action="" method="POST" enctype="multipart/form-data">
        <div class="form-group">
            <label for="title">Title:</label>
            <input type="text" id="title" name="title" required>
        </div>

        <div class="form-group">
            <label for="date-from">Date (From):</label>
            <input type="date" id="date-from" name="date_from" required>
        </div>

        <div class="form-group">
            <label for="date-to">Date (To):</label>
            <input type="date" id="date-to" name="date_to" required>
        </div>

        <div class="form-group">
            <label for="organised-by">Organized By:</label>
            <input type="text" id="organised-by" name="organised_by" required>
        </div>

        <div class="form-group">
            <label for="location">Location:</label>
            <input type="text" id="location" name="location" required>
        </div>

        <div class="form-group">
            <label for="certificate">Upload Certificate:</label>
            <input type="file" id="certificate" name="certificate" required>
        </div>

        <div class="form-group">
            <label for="certificate">Brochure:</label>
            <input type="file" id="Brochure" name="Brochure" required>
        </div>

        <div class="form-group">
            <label for="certificate">Fdp Schedule and Invitation:</label>
            <input type="file" id="fdp_s_i" name="fdp_s_i" required>
        </div>

        <div class="form-group">
            <label for="certificate">Attendance Forms:</label>
            <input type="file" id="attendence" name="attendence" required>
        </div>

        <div class="form-group">
            <label for="certificate">Feedback Forms:</label>
            <input type="file" id="feedback" name="feedback" required>
        </div>

        <div class="form-group">
            <label for="certificate">Fdp Report:</label>
            <input type="file" id="report" name="report" required>
        </div>

        <div class="form-group">
            <label for="certificate">Photo1:</label>
            <input type="file" id="Photo1" name="Photo1" required>
        </div>

        <div class="form-group">
            <label for="certificate">Photo2:</label>
            <input type="file" id="Photo2" name="Photo2" required>
        </div>

        <div class="form-group">
            <label for="certificate">Photo3:</label>
            <input type="file" id="Photo3" name="Photo3" required>
        </div>

        <button class="btn1" type="submit">Submit</button>
    </form>
</div>

</body>
</html>
