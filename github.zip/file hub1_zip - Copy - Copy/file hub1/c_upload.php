<?php
// Database configuration
include 'connection.php';
include 'header.php';

$event = htmlspecialchars($_GET['event'] ?? 'Unknown');

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $event_name = $_POST['event_name'];
    $fileName = $_POST['file_name'];
    $uploadedBy = $_POST['uploaded_by'];
    $fileTmpPath = $_FILES['file_upload']['tmp_name'];
    $fileNameStored = basename($_FILES['file_upload']['name']);
    $uploadDir = 'uploads/';
    $filePath = $uploadDir . $fileNameStored;

    // Handle photos
    $photoPaths = [];
    for ($i = 1; $i <= 4; $i++) {
        $photoKey = "photo$i";
        if (isset($_FILES[$photoKey]) && $_FILES[$photoKey]['error'] == 0) {
            $photoTmpPath = $_FILES[$photoKey]['tmp_name'];
            $photoName = basename($_FILES[$photoKey]['name']);
            $photoPath = $uploadDir . $photoName;
            if (move_uploaded_file($photoTmpPath, $photoPath)) {
                $photoPaths[] = $photoPath;
            }
        }
    }

    // Create uploads directory if it doesn't exist
    if (!is_dir($uploadDir)) {
        if (!mkdir($uploadDir, 0777, true) && !is_dir($uploadDir)) {
            die("Failed to create upload directory.");
        }
    }

    // Move the main file to the uploads directory
    if (file_exists($fileTmpPath) && move_uploaded_file($fileTmpPath, $filePath)) {
        // Prepare the SQL statement for storing file details including photos
        // Prepare the SQL statement for storing file details including photos
            $photo1 = $photoPaths[0] ?? null;
            $photo2 = $photoPaths[1] ?? null;
            $photo3 = $photoPaths[2] ?? null;
            $photo4 = $photoPaths[3] ?? null;

            $stmt = $conn->prepare("INSERT INTO central_files (event,event_name, file_name, file_path, uploaded_by, photo1, photo2, photo3, photo4) VALUES (?,?, ?, ?, ?, ?, ?, ?, ?)");
            $stmt->bind_param("sssssssss", $event,$event_name, $fileName, $filePath, $uploadedBy, $photo1, $photo2, $photo3, $photo4);

        
        if ($stmt->execute()) {
            echo "<script>alert('File and photos uploaded successfully!'); window.location.href = 'central_events.php';</script>";
        } else {
            echo "<script>alert('Database error: Could not save the file details.');</script>";
        }
        $stmt->close();
    } else {
        echo "<script>alert('Error uploading the file. Temporary file not found or move failed.');</script>";
    }
}

$conn->close();
?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>File Upload</title>
    <link rel="stylesheet" href="styles.css">
    <style>
        /* Global Styles */
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-image: url('./stuff/gmr_landing_page.jpg');
            background-size: cover;
            background-position: center;
            display: flex;
            justify-content: center;
            height: 100vh;
            color: #333;
        }

        body::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 130vh;
            background: rgba(0, 0, 0, 0.5);
            z-index: -1;
        }
        /* Container */
        .container {
            background:rgba(0, 0, 0, 0.6);
            padding: 2rem;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            width: 500px;
            margin-bottom: 50px;
        }

        .container11{
            margin-top: 150px;
            align-items: center;
            margin-bottom:100px;
        }
        /* Form */
        .upload-form h1 {
            text-align: center;
            margin-bottom: 1.5rem;
            color: #007bff;
        }
        .upload-form h2 {
            text-align: center;
            margin-bottom: 1.5rem;
            color:rgb(133, 38, 162);
        }

        .form-group {
            margin-bottom: 1rem;
        }

        label {
            display: block;
            margin-bottom: 0.5rem;
            font-weight: bold;
            color: white;
        }

        input[type="text"],
        input[type="file"] {
            width: 100%;
            padding: 0.5rem;
            border: 1px solid #ccc;
            border-radius: 5px;
            font-size: 1rem;
        }

        input[type="text"]:focus,
        input[type="file"]:focus {
            outline: none;
            border-color: #007bff;
        }
        .file{
            color: white;
        }
        .btn1{
            width: 80px;
            font-weight: bold;
            border-radius: 10px;
            border-style: none;
            height:30px;
            background-color: #007BFF;
        }
        .btn1:hover {
            background-color: #0056b3;
            transform: translateY(-3px);
            
        }
        
            </style>
            
</head>
<body>
    <div class="container11">
    <div class="container">
        <form action="" method="POST" enctype="multipart/form-data" class="upload-form">
            <h1>Login to <?php echo htmlspecialchars($event); ?> Events</h1>

            <h2>Upload a File</h2>
            <div class="form-group">
                <label for="event_name">Event Name:</label>
                <input type="text" id="event_name" name="event_name" placeholder="Enter event name" required>
            </div>
            <div class="form-group">
                <label for="file_name">File Name:</label>
                <input type="text" id="file_name" name="file_name" placeholder="Enter file name" required>
            </div>
            <div class="form-group">
                <label for="file_upload">Choose File:</label>
                <input type="file" id="file_upload" class="file" name="file_upload" required>
            </div>
            <div class="form-group">
                <label for="uploaded_by">Uploaded By:</label>
                <input type="text" id="uploaded_by" name="uploaded_by" placeholder="Your name" required>
            </div>
            <div class="form-group">
                    <label for="file_upload">Photo 1:</label>
                    <input type="file" id="file_upload" class="file" name="photo1">
                </div>
                <div class="form-group">
                    <label for="file_upload">Photo 2:</label>
                    <input type="file" id="file_upload" class="file" name="photo2">
                </div>
                <div class="form-group">
                    <label for="file_upload">Photo 3:</label>
                    <input type="file" id="file_upload" class="file" name="photo3">
                </div>
                <div class="form-group">
                    <label for="file_upload">Photo 4:</label>
                    <input type="file" id="file_upload" class="file" name="photo4">
                </div>

            <center><button type="submit" class="btn1">Upload</button></center>
        </form>
    </div>
    </div>
</body>
</html>

