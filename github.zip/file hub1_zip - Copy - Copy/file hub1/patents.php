<?php
    include("connection.php");
    session_start();
    if (!isset($_SESSION['username'])) {
        die("You need to log in to view your uploads.");
    }

    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        // Get session username
        $user = $_SESSION['username'];
        
        $branch_query = "SELECT dept FROM reg_tab WHERE userid = '$user'";
        $branch_result = $conn->query($branch_query);

        if ($branch_result && $branch_result->num_rows > 0) {
            $branch_row = $branch_result->fetch_assoc();
            $branch = $branch_row['dept'];
        } else {
            die("Branch not found for the user.");
        }

        $patent_title = $_POST['patent_title'];
        $date_of_issue = $_POST['date_of_issue'];

        // Handle file upload
        $patent_file = $_FILES['patent_file']['name'];
        $target_dir = "uploads/patents/";
        $target_file = $target_dir . basename($patent_file);

        if (move_uploaded_file($_FILES['patent_file']['tmp_name'], $target_file)) {
            date_default_timezone_set('Asia/Kolkata');

            $submission_time = date('Y-m-d H:i:s');

            // Insert query
            $sql = "INSERT INTO patents_table (Username, branch, patent_title, date_of_issue, patent_file, submission_time) 
            VALUES ('$user', '$branch', '$patent_title', '$date_of_issue', '$target_file', '$submission_time')";


            if ($conn->query($sql) === TRUE) {
                echo "<script>alert('Details uploaded successfully');</script>";
                echo "<script>window.location.href = 'acd_year.php';</script>";
            } else {
                echo "Error: " . $sql . "<br>" . $conn->error;
            }
        } else {
            echo "Sorry, there was an error uploading the patent file.";
        }
    }
    include 'header.php';
    $conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Patents</title>
    <link rel="stylesheet" href="./css/patents.css">
</head>
<body>
    <div class="container">
        <div class="contact-wrapper">
            <h1>Patents</h1>
            <form action="" method="post" enctype="multipart/form-data">
                <!-- Patent Title -->
                <div class="form-group">    
                    <label for="patent_title">Patent Title:</label>
                    <input type="text" id="patent_title" name="patent_title" placeholder="Enter Patent Title" required>
                </div>

                <!-- Date of Issue -->
                <div class="form-group">
                    <label for="date_of_issue">Date of Issue:</label>
                    <input type="date" id="date_of_issue" name="date_of_issue" required>
                </div>

                <!-- Patent File -->
                <div class="form-group">
                    <label for="patent_file">Upload Patent File:</label>
                    <input type="file" id="patent_file" name="patent_file" required>
                </div>

                <!-- Submit Button -->
                <button type="submit" class="btn1">Submit</button>
            </form>
        </div>
    </div>
</body>
</html>
