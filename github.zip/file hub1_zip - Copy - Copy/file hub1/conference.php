<?php

include 'connection.php';
session_start();
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
if (!isset($_SESSION['username'])) {
    die("You need to log in to view your uploads.");
}

// Handling form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    $user = $_SESSION['username'];

    $branch_query = "SELECT dept FROM reg_tab WHERE userid = '$user'";
        $branch_result = $conn->query($branch_query);

        if ($branch_result && $branch_result->num_rows > 0) {
            $branch_row = $branch_result->fetch_assoc();
            $branch = $branch_row['dept'];
        } else {
            die("Branch not found for the user.");
        }

    $paper_title = $_POST['paper_title'];
    $from_date = $_POST['from_date'];
    $to_date = $_POST['to_date'];
    $organised_by = $_POST['organised_by'];
    $location = $_POST['location'];
    $paper_type = $_POST['paper_type'];

    // Handle file uploads
    $certificate_path = '';
    if (isset($_FILES['certificate']) && $_FILES['certificate']['error'] == 0) {
        $certificate_path = 'uploads/' . basename($_FILES['certificate']['name']);
        move_uploaded_file($_FILES['certificate']['tmp_name'], $certificate_path);
    }

    $paper_file_path = '';
    if (isset($_FILES['paper_file']) && $_FILES['paper_file']['error'] == 0) {
        $paper_file_path = 'uploads/' . basename($_FILES['paper_file']['name']);
        move_uploaded_file($_FILES['paper_file']['tmp_name'], $paper_file_path);
    }

    // Insert data into the database
    date_default_timezone_set('Asia/Kolkata');

    $submission_time = date('Y-m-d H:i:s');

    // Insert data into the database
    $stmt = $conn->prepare("INSERT INTO conference_tab (username, branch, paper_title, from_date, to_date, organised_by, location, certificate_path, paper_type, paper_file_path, submission_time) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?,?)");
    $stmt->bind_param("sssssssssss", $user,$branch, $paper_title, $from_date, $to_date, $organised_by, $location, $certificate_path, $paper_type, $paper_file_path, $submission_time);

    if ($stmt->execute()) {
    echo "<script>alert('Submission successful!');</script>";
    echo "<script>window.location.href = 'acd_year.php';</script>";

} else {
    echo "<script>showPopup('Error: " . addslashes($stmt->error) . "');</script>";
}


    $stmt->close();
}

$conn->close();
?>

<?php 
    include 'header.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Conference Paper Submission</title>
    <link rel="stylesheet" href="./css/conf.css">
</head>
<body>

    <div class="container11">
        <h1>Conference Paper Submission Form</h1>

        <form id="conference-form" method="POST" enctype="multipart/form-data" action="">


            <!-- Paper Title -->
            <div class="input-group">
                <label for="paper-title">Paper Title:</label>
                <input type="text" id="paper-title" name="paper_title" required>
            </div>

            <!-- From and To Dates -->
            <div class="input-group">
                <label for="from-date">From Date:</label>
                <input type="date" id="from-date" name="from_date" required>
            </div>

            <div class="input-group">
                <label for="to-date">To Date:</label>
                <input type="date" id="to-date" name="to_date" required>
            </div>

            <!-- Organised By and Location -->
            <div class="input-group">
                <label for="organised-by">Organized By:</label>
                <input type="text" id="organised-by" name="organised_by" required>
            </div>

            <div class="input-group">
                <label for="location">Location:</label>
                <input type="text" id="location" name="location" required>
            </div>

            <!-- Certificate -->
            <div class="input-group">
                <label for="certificate">Certificate:</label>
                <input type="file" id="certificate" name="certificate" required>
            </div>

            <!-- Paper Type -->
            <div class="input-group">
                <label for="paper-type">Paper Type:</label>
                <select id="paper-type" name="paper_type" required>
                    <option value="participated">Participated</option>
                    <option value="paper_publication">Paper Publication</option>
                    <option value="poster_presentation">Poster Presentation</option>
                </select>
            </div>

            <!-- Paper File (conditional visibility) -->
            <div id="paper-upload-div" class="input-group">
                <label for="paper-file">Paper :</label>
                <input type="file" id="paper-file" name="paper_file">
            </div>

            <button class="btn1" type="submit">Submit</button>

        </form>
    </div>

    <script src="./css/conf.js"></script>
</body>
</html>
