<?php
    include("connection.php");
    session_start();
    if (!isset($_SESSION['username'])) {
        die("You need to log in to view your uploads.");
    }

    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        // Get session username
        $user = $_SESSION['username'];

        $branch_query = "SELECT dept FROM reg_tab WHERE userid = '$user'";
        $branch_result = $conn->query($branch_query);

        if ($branch_result && $branch_result->num_rows > 0) {
            $branch_row = $branch_result->fetch_assoc();
            $branch = $branch_row['dept'];
        } else {
            die("Branch not found for the user.");
        }

        $paper_title = $_POST['paper_title'];
        $journal_name = $_POST['journal_name'];
        $indexing = $_POST['indexing'];
        $date_of_submission = $_POST['date_of_submission'];
        $quality_factor = $_POST['quality_factor'];
        $impact_factor = $_POST['impact_factor'];
        $payment = $_POST['payment'];

        // Handle file upload
        $file_name = $_FILES['paper_file']['name'];
        $file_tmp_name = $_FILES['paper_file']['tmp_name'];
        $file_size = $_FILES['paper_file']['size'];
        $file_error = $_FILES['paper_file']['error'];

        if ($file_error === 0) {
            $file_extension = pathinfo($file_name, PATHINFO_EXTENSION);
            $allowed_extensions = ['pdf', 'doc', 'docx'];

            if (in_array(strtolower($file_extension), $allowed_extensions)) {
                $file_new_name = uniqid('', true) . "." . $file_extension;
                $file_destination = 'uploads/' . $file_new_name;
                
                if (move_uploaded_file($file_tmp_name, $file_destination)) {
                    date_default_timezone_set('Asia/Kolkata');

                    $submission_time = date('Y-m-d H:i:s');
                    // SQL query to insert data into published_tab table
                    $sql = "INSERT INTO published_tab (username, branch, paper_title, journal_name, indexing, date_of_submission, quality_factor, impact_factor, payment, submission_time, paper_file)
                            VALUES ('$user', '$branch', '$paper_title', '$journal_name', '$indexing', '$date_of_submission', '$quality_factor', '$impact_factor', '$payment', '$submission_time', '$file_destination')";

                    if ($conn->query($sql) === TRUE) {
                        echo "<script>alert('Details and paper uploaded successfully');</script>";
                    } else {
                        echo "Error: " . $sql . "<br>" . $conn->error;
                    }
                } else {
                    echo "<script>alert('There was an error uploading your file.');</script>";
                }
            } else {
                echo "<script>alert('Invalid file type. Only PDF, DOC, DOCX files are allowed.');</script>";
            }
        } else {
            echo "<script>alert('There was an error with the file upload.');</script>";
        }
    }
    include 'header.php';
    $conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Papers Published</title>
    <link rel="stylesheet" href="./css/publish.css">
</head>
<body>
    <div class="container11">
        <div class="contact-wrapper">
        <div class="contact-form">
            <h2>Enter Paper Details</h2>
            <form action="" method="POST" id="contactForm" enctype="multipart/form-data">
                <div class="form-group">
                    <label for="paper_title">Paper Title</label>
                    <input type="text" id="paper_title" name="paper_title" required>
                </div>
                <div class="form-group">
                    <label for="journal_name">Journal Name</label>
                    <input type="text" id="journal_name" name="journal_name" required>
                </div>
                <div class="form-group">
                    <label for="indexing">Indexing</label>
                    <select id="indexing" name="indexing" required>
                        <option value="scopus">Scopus</option>
                        <option value="sci">SCI</option>
                        <option value="scie">SCIE</option>
                        <option value="ugc_care">UGC Care</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="date_of_submission">Date of Submission</label>
                    <input type="date" id="date_of_submission" name="date_of_submission" required>
                </div>
                <div class="form-group">
                    <label for="quality_factor">Quality Factor</label>
                    <input type="number" id="quality_factor" name="quality_factor" step="0.01" min="0" required>
                </div>
                <div class="form-group">
                    <label for="impact_factor">Impact Factor</label>
                    <input type="number" id="impact_factor" name="impact_factor" step="0.01" min="0" required>
                </div>
                <div class="form-group">
                    <label for="payment">Payment</label>
                    <select id="payment" name="payment" required>
                        <option value="free">Free</option>
                        <option value="paid">Paid</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="paper_file">Upload Paper</label>
                    <input type="file" id="paper_file" name="paper_file" accept=".pdf, .doc, .docx" required>
                </div>
                <button type="submit" class="btn btn-outline">Submit</button>
            </form>
        </div>
        </div>
    </div>
</body>
</html>
