
<table>
            <thead>
                <tr>
                    <th colspan="4" id="th1">Criteria <?php echo $criteria; ?></th>
                </tr>
                <tr id="tr2">
                    <th>Criteria No</th>
                    <th>Description</th>
                    <th>Action</th>
                </tr>
            </thead>
                

        </table>