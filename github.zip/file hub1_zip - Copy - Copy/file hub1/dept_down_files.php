<?php
include "connection.php";
session_start();

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get the username from the session
if (!isset($_SESSION['username'])) {
    die("Please login to access this page.");
}
$username = $_SESSION['username'];


// Check if download request is made
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['file_type'])) {
    $file_type = $_POST['file_type'];

    // Prepare the SQL query to fetch records for the specific file type
    $sql = "SELECT file_type, sub_file_type, file_name FROM dept_files WHERE username = ? AND file_type = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ss", $username, $file_type);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        // Generate .xls file
        header("Content-Type: application/vnd.ms-excel");
        header("Content-Disposition: attachment; filename=\"$file_type-files.xls\"");
        header("Pragma: no-cache");
        header("Expires: 0");

        // Output the table headers
        echo "ID\tUsername\tFile Type\tFile Name\n";

        $id = 1;
        while ($row = $result->fetch_assoc()) {
            echo $id . "\t" . $username . "\t" . $row['sub_file_type'] . "\t" . $row['file_name'] . "\n";
            $id++;
        }

        exit();
    } else {
        echo "<script>alert('No records found for $file_type');</script>";
    }
}
include "./header.php";
// HTML and CSS for displaying tables
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Retrieve Files</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            margin: 0;
            padding: 0;
            background: linear-gradient(135deg, #6a11cb, #2575fc);
            color: white;
            display: flex;
            justify-content: center;
            min-height: 100vh;
        }

        .container11 {
            margin-top: 100px;
            margin-bottom: 70px;
            background: rgba(255, 255, 255, 0.1);
            padding: 20px;
            border-radius: 15px;
            box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.3);
            width: 80vw;
            height: 100%;
        }

        h1 {
            text-align: center;
            font-size: 2.5rem;
            margin-bottom: 1rem;
            color: #fff;
        }

        h2 {
            margin-top: 20px;
            font-size: 1.8rem;
            text-align: center;
            color: #ffdf6c;
        }

        .styled-table {
            width: 100%;
            margin-top: 20px;
            border-collapse: collapse;
            text-align: left;
            background: rgba(255, 255, 255, 0.2);
            border-radius: 10px;
            overflow: hidden;
        }

        .styled-table thead tr {
            background: rgb(50, 29, 90);
            color: white;
            font-weight: bold;
        }

        .styled-table th,
        .styled-table td {
            padding: 15px;
            text-align: center;
        }

        .styled-table tbody tr {
            border-bottom: 1px solid rgba(255, 255, 255, 0.2);
        }

        .styled-table tbody tr:nth-of-type(even) {
            background: rgba(255, 255, 255, 0.1);
        }

        .btn {
            display: inline-block;
            padding: 8px 12px;
            font-size: 1rem;
            text-decoration: none;
            border-radius: 5px;
            color: white;
            font-weight: bold;
            margin-right: 10px;
        }

        .view-btn {
            background: #42a5f5;
        }

        .view-btn:hover {
            background: #1e88e5;
        }

        .download-btn {
            background: #66bb6a;
        }

        .download-btn:hover {
            background: #43a047;
        }

        form {
            text-align: center;
            margin-bottom: 20px;
        }
    </style>
</head>
<body>
    <div class="container11">
        <h1>Retrieve Files</h1>
        <?php
        // Define file type arrays
        $file_types = array('admin', 'faculty', 'student', 'exam_section'); 

        foreach ($file_types as $file_type) {
            // Prepare the SQL query to fetch records filtered by username and file type
            $sql = "SELECT file_type, sub_file_type, file_name, file_path FROM dept_files WHERE username = ? AND file_type = ?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("ss", $username, $file_type);
            $stmt->execute();
            $result = $stmt->get_result();

            if ($result->num_rows > 0) {
                echo "<h2>" . ucfirst(str_replace("_", " ", $file_type)) . " Files</h2>";
                echo "<form method='post'>
                        <input type='hidden' name='file_type' value='$file_type'>
                        <button type='submit' class='btn download-btn'>Download Excel</button>
                      </form>";
                echo "<table class='styled-table'>
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>User Name</th>
                                <th>File Type</th>
                                <th>File Name</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>";

                // Initialize ID counter for each file type
                $id = 1; 

                while ($row = $result->fetch_assoc()) {
                    echo "<tr>
                            <td>" . $id . "</td> 
                            <td>" . $username . "</td>
                            <td>" . $row['sub_file_type'] . "</td>
                            <td>" . $row['file_name'] . "</td>
                            <td>
                                <a href='" . $row['file_path'] . "' target='_blank' class='btn view-btn'>View</a>
                                <a href='" . $row['file_path'] . "' download class='btn download-btn'>Download</a>
                            </td>
                        </tr>";
                    $id++; // Increment ID for the next row
                }

                echo "</tbody></table>";
            } 
            $stmt->close();
        }

        ?>
    </div>
</body>
</html>
<?php $conn->close(); ?>
