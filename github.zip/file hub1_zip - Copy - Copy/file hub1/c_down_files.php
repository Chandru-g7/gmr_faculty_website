<?php
include("connection.php");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Export to Excel
if (isset($_POST['export'])) {
    header("Content-Type: application/vnd.ms-excel");
    header("Content-Disposition: attachment; filename=event_records.xls");

    // Write the Excel content
    echo "ID\tEvent Name\tFile Name\tUploaded By\n";

    $sql = "SELECT * FROM central_files WHERE event = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $_POST['event']);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        $no = 1;
        while ($row = $result->fetch_assoc()) {
            echo $no . "\t" .
                $row['event_name'] . "\t" .
                $row['file_name'] . "\t" .
                $row['uploaded_by'] . "\n";
            $no++;
        }
    }
    exit;
}
?>
<?php
include "./header.php";
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Event Records</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background: linear-gradient(to right, #74ebd5, #9face6);
        }
        .cont11 {
            width: 90%;
            padding: 20px;
            border-radius: 5px;
        }
        .div1 {
            margin-top: 150px;
            margin-left: 100px;
            width: 90%;
            padding: 20px;
            background: #fff;
            border-radius: 5px;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.2);
        }
        h1 {
            text-align: center;
            margin: 20px 0;
            color: #333;
        }
        form {
            display: flex;
            flex-direction: column;
            align-items: center;
            margin: 20px auto;
        }
        label {
            font-size: 18px;
            margin-bottom: 10px;
        }
        select {
            width: 300px;
            padding: 10px;
            margin-bottom: 20px;
            border: 1px solid #ccc;
            border-radius: 5px;
            font-size: 16px;
        }
        .button {
            background-color: #007bff;
            color: #fff;
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            font-size: 16px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }
        .button:hover {
            background-color: #0056b3;
        }
        .view-btn, .download-btn {
            display: inline-block;
            padding: 8px 12px;
            margin: 5px;
            border-radius: 5px;
            text-decoration: none;
            font-size: 14px;
            font-weight: bold;
            color: #fff;
            transition: background-color 0.3s ease, box-shadow 0.3s ease;
        }
        .view-btn {
            background-color: #28a745;
        }
        .view-btn:hover {
            background-color: #218838;
            box-shadow: 0px 0px 10px rgba(40, 167, 69, 0.5);
        }
        .download-btn {
            background-color: #17a2b8;
        }
        .download-btn:hover {
            background-color: #138496;
            box-shadow: 0px 0px 10px rgba(23, 162, 184, 0.5);
        }
        table {
            width: 90%;
            margin: 20px auto;
            border-collapse: collapse;
            background-color: #fff;
        }
        table, th, td {
            border: 1px solid #ddd;
        }
        th, td {
            padding: 12px;
            text-align: center;
        }
        th {
            background-color: #007bff;
            color: #fff;
        }
        tr:nth-child(even) {
            background-color: #f2f2f2;
        }
        p {
            text-align: center;
            font-size: 18px;
            color: #666;
        }
        .download-all-btn {
            position: absolute;
            top: 20px;
            right: 20px;
            background-color: #ffc107;
            color: #333;
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            font-size: 16px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }
        .download-all-btn:hover {
            background-color: #e0a800;
        }
    </style>
</head>
<body>
        
    <div class="cont11">
   
        <div class="div1">
            <?php if (isset($_POST['event']) && !empty($_POST['event'])): ?>
                <form method="POST" style="position: relative;">
                    <input type="hidden" name="event" value="<?php echo htmlspecialchars($_POST['event']); ?>">
                    <button type="submit" name="export" class="download-all-btn">Download All as Excel</button>
                </form>
            <?php endif; ?>
            
            <h1>Select Event</h1>
            <form action="" method="POST">
                <label for="event">Choose an Event:</label>
                <select name="event" id="event" required>
                    <option value="">--Select an Event--</option>
                    <option value="NCC">NCC</option>
                    <option value="Sports">Sports</option>
                    <option value="NSS">NSS</option>
                    <option value="Women Empowerment">Women Empowerment</option>
                    <option value="IIC">IIC</option>
                    <option value="PASH">PASH</option>
                    <option value="Antiragging">Antiragging</option>
                    <option value="SAC">SAC</option>
                </select>
                <button type="submit" class="button">Submit</button>
            </form>
            
            <?php
                if ($_SERVER['REQUEST_METHOD'] === 'POST') {
                    $event = $_POST['event'];

                    // Fetch records based on the selected event
                    $sql = "SELECT * FROM central_files WHERE event = ?";
                    $stmt = $conn->prepare($sql);
                    $stmt->bind_param("s", $event);
                    $stmt->execute();
                    $result = $stmt->get_result();

                    echo "<h1>Records for Event: " . htmlspecialchars($event) . "</h1>";
                    if ($result->num_rows > 0) {
                        $no=1;
                        echo "<table>\n";
                        echo "<tr><th>ID</th><th>Event Name</th><th>File Name</th><th>Uploaded By</th><th>File Path</th><th>Photo1</th><th>Photo2</th><th>Photo3</th><th>Photo4</th></tr>\n";
                        while ($row = $result->fetch_assoc()) {
                            echo "<tr>";
                            echo "<td>" . htmlspecialchars($no) . "</td>";
                            echo "<td>" . htmlspecialchars($row['event_name']) . "</td>";
                            echo "<td>" . htmlspecialchars($row['file_name']) . "</td>";
                            echo "<td>" . htmlspecialchars($row['uploaded_by']) . "</td>";
                            echo "<td><a href='" . htmlspecialchars($row['file_path']) . "' class='view-btn' target='_blank'>View</a> <a href='" . htmlspecialchars($row['file_path']) . "' download class='download-btn'>Download</a></td>";
                            echo "<td>" . (!empty($row['photo1']) ? "<a href='" . htmlspecialchars($row['photo1']) . "' class='view-btn' target='_blank'>View</a> <a href='" . htmlspecialchars($row['photo1']) . "' download class='download-btn'>Download</a>" : "No Photo") . "</td>";
                            echo "<td>" . (!empty($row['photo2']) ? "<a href='" . htmlspecialchars($row['photo2']) . "' class='view-btn' target='_blank'>View</a> <a href='" . htmlspecialchars($row['photo2']) . "' download class='download-btn'>Download</a>" : "No Photo") . "</td>";
                            echo "<td>" . (!empty($row['photo3']) ? "<a href='" . htmlspecialchars($row['photo3']) . "' class='view-btn' target='_blank'>View</a> <a href='" . htmlspecialchars($row['photo3']) . "' download class='download-btn'>Download</a>" : "No Photo") . "</td>";
                            echo "<td>" . (!empty($row['photo4']) ? "<a href='" . htmlspecialchars($row['photo4']) . "' class='view-btn' target='_blank'>View</a> <a href='" . htmlspecialchars($row['photo4']) . "' download class='download-btn'>Download</a>" : "No Photo") . "</td>";
                            echo "</tr>\n";
                            $no++;
                        }
                        echo "</table>\n";
                    } else {
                        echo "<p>No records found for the selected event.</p>";
                    }

                    $stmt->close();
                }

                $conn->close();
            ?>
            
        </div>
    </div>
</body>
</html>
