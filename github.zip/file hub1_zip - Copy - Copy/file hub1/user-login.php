<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Login</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            height: 100vh;
            background-color: #f4f4f4;
            margin: 0;
        }
        h1 {
            margin-bottom: 40px;
            color: #333;
        }
        .container {
            text-align: center;
        }
        .btn {
            display: inline-block;
            padding: 15px 30px;
            margin: 15px;
            font-size: 18px;
            color: white;
            background-color: #007bff;
            text-decoration: none;
            border-radius: 5px;
            border: none;
            cursor: pointer;
        }
        .btn:hover {
            background-color: #0056b3;
        }
        .btn:active {
            background-color: #003f7f;
        }
    </style>
</head>
<body>
    <h1>Admin Login Page</h1>
    <div class="container">
        <p>This is a placeholder for the admin login page.</p>
        <button class="btn" onclick="location.href='index.php'">Back to Home</button>
    </div>
</body>
</html>
