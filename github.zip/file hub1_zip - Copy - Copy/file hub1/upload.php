<?php
include("connection.php");
session_start();

if (!isset($_SESSION['username'])) {
    die("You need to log in to view your uploads.");
}

// Get the academic year, criteria, and criteria number from the POST request
$academic_year = isset($_POST['academic_year']) ? $_POST['academic_year'] : '';
$criteria = isset($_POST['criteria']) ? $_POST['criteria'] : '';
$criteria_no = isset($_POST['criteria_no']) ? $_POST['criteria_no'] : '';

date_default_timezone_set('Asia/Kolkata');

if (isset($_POST['upload'])) {
    // Retrieve the username from the session
    $username = $_SESSION['username'];
    $faculty_name = $_POST['faculty_name'];
    $filename = $_POST['file_name'];
    $branch = isset($_POST['branch']) ? $_POST['branch'] : '';
    $sem = isset($_POST['sem']) ? $_POST['sem'] : ''; // Semester is optional and set based on criteria_no
    $section = isset($_POST['section']) ? $_POST['section'] : '';
    $ext_or_int = isset($_POST['ext_or_int']) ? $_POST['ext_or_int'] : ''; // For Ext or Int
    $targetDir = "uploads/";
    $currentDateTime = date('Y-m-d H:i:s'); // Get current date and time

    // Create directory if it doesn't exist
    if (!is_dir($targetDir)) {
        mkdir($targetDir, 0777, true);
    }

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    $uploadSuccess = false;
    foreach ($_FILES['files']['name'] as $key => $file_name) {
        $filepath = $targetDir . basename($file_name);

        if (move_uploaded_file($_FILES['files']['tmp_name'][$key], $filepath)) {
            // Use prepared statements to prevent SQL injection
            $sql = "INSERT INTO files (UserName, academic_year, branch, sem, section, faculty_name, ext_or_int, uploaded_at, file_name, file_path, criteria, criteria_no) 
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("ssssssssssss", $username, $academic_year, $branch, $sem, $section, $faculty_name, $ext_or_int, $currentDateTime, $filename, $filepath, $criteria, $criteria_no);

            if ($stmt->execute()) {
                $uploadSuccess = true;
            } else {
                echo "Error: " . $stmt->error;
            }
        } else {
            echo "<p class='error-message'>Error moving uploaded file: $filename</p>";
        }
    }
    
    $stmt->close();
    $conn->close();
    if ($uploadSuccess) {
        echo "<script>alert('File(s) uploaded successfully.');</script>";
    }
    

}
?>
<?php
    include './header.php';
    ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>File Upload</title>
    <link rel='stylesheet' href="css/upload_a.css">
    <style>
        .lg{
            background-color: red;
        }
    </style>
</head>
<body>
    
    

    <div class="upload-container">
        <h1>Upload Files</h1>
        <form action="upload.php" method="POST" enctype="multipart/form-data" onsubmit="return validateForm()">
            <!-- Hidden fields for academic_year, criteria, and criteria_no -->
            <input type="hidden" name="academic_year" id="academic_year" value="<?php echo $academic_year; ?>">
            <input type="hidden" name="criteria" id="criteria" value="<?php echo $criteria; ?>">
            <input type="hidden" name="criteria_no" id="criteria_no" value="<?php echo $criteria_no; ?>">

            <label for="faculty_name">Faculty Name:</label>
            <input type="text" id="faculty_name" name="faculty_name" required>

            <?php if ($criteria_no == '6.1.1(A)' || $criteria_no == '6.1.1(F)' || $criteria_no == '6.1.1(I)' ): ?>
            <label for="branch">Branch:</label>
            <select id="branch" name="branch" onchange="updateSemOptions()" required>
                <option value="" disabled selected>Select the branch</option>
                <option value="AIDS">AIDS</option>
                <option value="AIML">AIML</option>
                <option value="CSE">CSE</option>
                <option value="CIVIL">CIVIL</option>
                <option value="MECH">MECH</option>
                <option value="EEE">EEE</option>
                <option value="ECE">ECE</option>
                <option value="IT">IT</option>
                <option value="BSH">BSH</option>
            </select>
            <?php endif; ?>

            <?php if ($criteria_no == '6.1.1(A)'):?>
            <label for="sem">Semester:</label>
            <select id="sem" name="sem" required>
                <!-- Options will be dynamically populated based on branch selection -->
            </select>

            <label for="section">Section:</label>
            <input type="text" id="section" name="section" required>
            <?php endif; ?>

            <?php if ($criteria_no == '6.1.1(F)'): ?>
            <label for="ext_or_int">Ext or Int:</label>
            <select id="ext_or_int" name="ext_or_int" required>
                <option value="" disabled selected>Choose one</option>
                <option value="Internal">Internal</option>
                <option value="External">External</option>
            </select>
            <?php endif; ?>

            <label for="file_name">File Name:</label>
            <input type="text" id="file_name" name="file_name" required>

            <label for="file">Choose files to upload:</label>
            <input type="file" id="file" name="files[]" multiple required>

            <button type="submit" class="button1" name="upload" id='but'>Upload</button>
        </form>

    </div>

</body>
<script>
    function updateSemOptions() {
        var branch = document.getElementById('branch').value;
        var sem = document.getElementById('sem');
        sem.innerHTML = ''; // Clear previous options

        if (branch === 'BSH') {
            sem.innerHTML += '<option value="" disabled selected>select sem</option>';
            sem.innerHTML += '<option value="1">1</option>';
            sem.innerHTML += '<option value="2">2</option>';
        } else {
            sem.innerHTML += '<option value="" disabled selected>select sem</option>';
            for (var i = 3; i <= 8; i++) {
                sem.innerHTML += '<option value="' + i + '">' + i + '</option>';
            }
        }
    }

    function validateForm() {
        var academic_year = document.getElementById('academic_year').value;
        var criteria = document.getElementById('criteria').value;
        var criteria_no = document.getElementById('criteria_no').value;

        if (academic_year === '' || criteria === '' || criteria_no === '') {
            alert('Please fill out the academic year, criteria, and criteria number.');
            return false; // Prevent form submission
        }

        return true; // Proceed with form submission if validation passes
    }
</script>
</html>
