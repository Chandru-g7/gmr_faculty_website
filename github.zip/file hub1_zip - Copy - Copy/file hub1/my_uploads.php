<?php
include("connection.php");
session_start();


if (!isset($_SESSION['username'])) {
    die("You need to log in to view your uploads.");
}

$username = $_SESSION['username'];

// Handle file deletion
if (isset($_GET['delete'])) {
    $fileId = intval($_GET['delete']);
    $sql = "SELECT file_path FROM files WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $fileId);
    $stmt->execute();
    $result = $stmt->get_result();
    $file = $result->fetch_assoc();
    if ($file) {
        if (unlink($file['file_path'])) {
            $sql = "DELETE FROM files WHERE id = ?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("i", $fileId);
            $stmt->execute();
        } else {
            echo "<p class='error-message'>Error deleting the file.</p>";
        }
    }
}

// Handle Excel download
if (isset($_GET['download_excel'])) {
    header("Content-Type: application/vnd.ms-excel");
    header("Content-Disposition: attachment; filename=my_uploads.xls");

    // Start output buffering
    $output = fopen("php://output", "w");

    // Write the table headers
    fputcsv($output, [
        "Username",
        "Faculty Name",
        "Academic Year",
        "Branch",
        "Semester",
        "Section",
        "Filename",
        "Uploaded At",
        "Criteria No"
    ], "\t");

    // Fetch the user's files
    $sql = "SELECT * FROM files WHERE username = ? ORDER BY uploaded_at DESC";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();

    // Write the rows to the output
    while ($row = $result->fetch_assoc()) {
        $uploadedAt = new DateTime($row['uploaded_at']);
        $formattedDateTime = $uploadedAt->format('Y/m/d') . ' ' . $uploadedAt->format('H:i:s');
        fputcsv($output, [
            $username,
            $row['faculty_name'],
            $row['academic_year'],
            $row['branch'],
            $row['sem'],
            $row['section'],
            $row['file_name'],
            $formattedDateTime,
            $row['criteria_no']
        ], "\t");
    }

    // Close the output stream
    fclose($output);
    exit;
}
?>
<?php 
    include("header.php"); 
    ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Uploads</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f8f9fa;
        }
        .cont {
            width: 100%;
            padding: 20px;
            background: #fff;
            border-radius: 8px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
        }
        .container11{
            margin-top:100px;
            width:90%;
            margin-left:50px;
        }
        h1 {
            text-align: center;
            color: #333;
            margin-bottom: 20px;
            font-size: 2em;
            font-weight: bold;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin: 20px 0;
        }
        th, td {
            text-align: left;
            padding: 12px;
            border: 1px solid #ddd;
        }
        th {
            background-color: #007bff;
            color: #fff;
            text-transform: uppercase;
        }
        tr:nth-child(even) {
            background-color: #f2f2f2;
        }
        tr:hover {
            background-color: #e9ecef;
        }
        button {
            border: none;
            border-radius: 5px;
            padding: 8px 16px;
            font-size: 14px;
            cursor: pointer;
            text-transform: uppercase;
            font-weight: bold;
        }
        button#view {
            background-color: #28a745;
            color: white;
        }
        button#down {
            background-color: #007bff;
            color: white;
        }
        button#del {
            background-color: #dc3545;
            color: white;
        }
        .excel-btn {
            display: inline-block;
            margin: 10px;
            padding: 10px 20px;
            background-color: #28a745;
            color: white;
            border-radius: 5px;
            text-decoration: none;
            font-weight: bold;
            text-align: center;
        }
        .excel-btn:hover {
            background-color: #218838;
            box-shadow: 0 0 8px rgba(0, 0, 0, 0.2);
        }
    </style>
</head>
<body>
    <div class="cont">
    <div class="container11">
        <a href="my_uploads.php?download_excel=1" class="excel-btn">Download Excel</a>
        <h1>My Uploads</h1>
        <table>
            <tr>
                <th>Username</th>
                <th>Faculty Name</th>
                <th>Academic Year</th>
                <th>Branch</th>
                <th>Semester</th>
                <th>Section</th>
                <th>Filename</th>
                <th>Uploaded At</th>
                <th>Criteria No</th>
                <th>View</th>
                <th>Download</th>
                <th>Delete</th>
            </tr>
            <?php
            $sql = "SELECT * FROM files WHERE username = ? ORDER BY uploaded_at DESC";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("s", $username);
            $stmt->execute();
            $result = $stmt->get_result();

            if ($result->num_rows > 0) {
                while($row = $result->fetch_assoc()) {
                    $uploadedAt = new DateTime($row['uploaded_at']);
                    $formattedDateTime = $uploadedAt->format('Y/m/d') . ' & ' . $uploadedAt->format('H:i:s');
                    echo "<tr>";
                    echo "<td>" . htmlspecialchars($username) . "</td>";
                    echo "<td>" . htmlspecialchars($row['faculty_name']) . "</td>";
                    echo "<td>" . htmlspecialchars($row['academic_year']) . "</td>";
                    echo "<td>" . htmlspecialchars($row['branch']) . "</td>";
                    echo "<td>" . htmlspecialchars($row['sem']) . "</td>";
                    echo "<td>" . htmlspecialchars($row['section']) . "</td>";
                    echo "<td>" . htmlspecialchars($row['file_name']) . "</td>";
                    echo "<td>" . $formattedDateTime . "</td>";
                    echo "<td>" . htmlspecialchars($row['criteria_no']) . "</td>";
                    echo "<td><a href='" . htmlspecialchars($row['file_path']) . "' target='_blank'><button id='view'>View</button></a></td>";
                    echo "<td><a href='" . htmlspecialchars($row['file_path']) . "' download><button id='down'>Download</button></a></td>";
                    echo "<td><a href='?delete=" . htmlspecialchars($row['id']) . "' onclick=\"return confirm('Are you sure you want to delete this file?');\"><button id='del'>Delete</button></a></td>";
                    echo "</tr>";
                }
            } else {
                echo "<tr><td colspan='12'>No files found</td></tr>";
            }
            ?>
        </table>
    </div>
    </div>
</body>
</html>
