<?php
include './header.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>FMS</title>
    <link rel="stylesheet" href="./css/index.css">
</head>
<body>
    <main class="hero">
        <div class="container">
            <div class="hero-content">
                <h1>About GMRIT</h1>
                
                <div class="description">
                    <p>
                    Welcome to GMR Institute of Technology (GMRIT).
                    Established in the year 1997 by GMR Varalakshmi Foundation – the corporate social responsibility arm of GMR Group – GMRIT offers aspiring engineers high quality technical education.Located in Rajam, Vizianagaram district of Andhra Pradesh, GMRIT provides its learning community state-of-the-art facilities, infrastructure and a competent faculty. The Institute encourages collaborative learning between industry and academia as a means of reinforcing its curriculum with practical and real world experiences. It is this emphasis on a well-rounded education that makes GMRIT a preferred institute among engineering colleges in India.
                    </p>
                </div>
                
            </div>
        </div>
    </main>

 
</body>
</html>